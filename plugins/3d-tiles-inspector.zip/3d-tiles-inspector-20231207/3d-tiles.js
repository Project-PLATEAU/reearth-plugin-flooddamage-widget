reearth.ui.show(
  `
<style>
  html,
  body {
    display: none;
    margin: 6px 0 0 0;
  }

  .data-set-frame {
    font-size: 14px;
    margin: 0 12px 0 12px;
    background-color: #d9d9d9;
    gap: 10px;
    display: flex;
    flex-direction: column;
  }

  .data-set {
    background: #FFFFFF;
    box-shadow: rgba(0, 0, 0, 0.25) 1px 2px 4px;
    border-radius: 4px !important;
  }

  .details {
    cursor: pointer;
  }

  .details summary {
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
    cursor: pointer;
    border-bottom: 1px solid #E0E0E0;
    padding: 12px;
  }

  .details summary::-webkit-details-marker {
    display: none;
  }

  .details summary::after {
    content: '';
    width: var(--icon-normal, 16px);
    height: var(--icon-normal, 16px);
    background-image: url('data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2216%22%20height%3D%2216%22%20viewBox%3D%220%200%2016%2016%22%20fill%3D%22none%22%3E%3Cpath%20d%3D%22M11.3125%2013.1315L11.3125%202.86897C11.3125%202.56116%2010.9875%202.38928%2010.7656%202.57991L4.81562%207.71116C4.64531%207.85803%204.64531%208.14084%204.81562%208.28928L10.7656%2013.4205C10.9875%2013.6112%2011.3125%2013.4393%2011.3125%2013.1315Z%22%20fill%3D%22%234A4A4A%22%2F%3E%3C%2Fsvg%3E');
    transition: transform .3s;
  }

  .details[open] summary::after {
    transform: rotate(-90deg);
  }

  .flood-info-frame,
  .build-info-frame {
    display: flex;
    padding: 12px var(--radius-normal, 6px);
    flex-direction: column;
    align-items: flex-start;
    gap: var(--radius-normal, 6px);
    align-self: stretch;
  }

  .item {
    display: flex;
    padding-left: 24px;
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
    align-self: stretch;
  }

  .item-common {
    display: flex;
    padding: var(--radius-small, 4px) 0px;
    align-items: center;
    gap: 8px;
    align-self: stretch;
    border-bottom: 1px solid var(--neutral-5, #D9D9D9);
  }

  .item-field {
    width: 50%;
    color: var(--character-primary-85, rgba(0, 0, 0, 0.85));
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
  }

  .item-data {
    width: 50%;
    display: flex;
    gap: var(--radius-small, 4px);
    font-size: 14px;
  }

  .item-data-color {
    height: 18px;
    margin: auto 0;
    border: 0.5px solid #000000;
  }
</style>
<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/locale/ja.js"></script>
<script>
  function clearChildren(target) {
    const buildInfoFrame = document.querySelector(target);
    while (buildInfoFrame.firstChild) {
      buildInfoFrame.removeChild(buildInfoFrame.firstChild);
    }
  }

  function openWidget() {
    document.body.style.display = 'block';
    document.documentElement.style.display = 'block';
    let element = document.getElementsByClassName('data-set-frame')[0];
    element.scrollTo(0, 0);
  }

  let buildings = undefined;
  let cachedCsvUrl = undefined;
  let settings = undefined;

  function generateFloodInformation(building) {
    let components = [];
    const labels = {
      "'flood_category'": "浸水カテゴリ",
      "'flood_depth'": "浸水深さ",
      "'gid'": "gid",
      "'lon'": "経度",
      "'lat'": "緯度",
      "'dem'": "標高",
    };
    Object.keys(labels).forEach(key => {
      const label = labels[key];
      let value = building[key].replaceAll("'", "");
      if (key === "'flood_category'") {
        const classes = value.replaceAll(/（|）/g, ",").split(",");
        const color = settings?.colors?.[classes[0]]?.[classes[1]] ?? "#FFFFFF";
        value = '<div class="item-data-color"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="18" height="18" fill="' + color + '"/></svg></div>' + value;
      }
      components.push('<div class="item">');
      components.push('<div class="item-common">');
      components.push('<div class="item-field">' + label + '</div>');
      components.push('<div class="item-data">' + value + '</div>');
      components.push('</div>');
      components.push('</div>');
    })
    return components;
  }

  function generateBuildingInformation(layer) {
    let components = [];
    Object.keys(layer).forEach(key => {
      components.push('<div class="item">');
      components.push('<div class="item-common">');
      components.push('<div class="item-field">' + key + '</div>');
      components.push('<div class="item-data">' + layer[key] + '</div>');
      components.push('</div>');
      components.push('</div>');
    })
    return components;
  }

  function insertComponents(target, componentsHTML) {
    const buildInfoFrame = document.querySelector(target);
    buildInfoFrame.innerHTML = componentsHTML;
  }

  function generateComponents(layer) {
    const floodInfoTitle = document.querySelector('#flood-info-title');
    floodInfoTitle.innerHTML = '浸水情報（' + settings.title + '）';

    const building = buildings?.find(element => {
      return element["'gid'"] === ("'" + layer.gml_id + "'")
    });
    if (building) {
      const floodInformation = generateFloodInformation(building);
      insertComponents('.flood-info-frame', floodInformation.join(''));
    }

    const buildingInformation = generateBuildingInformation(layer);
    insertComponents('.build-info-frame', buildingInformation.join(''));
  }

  let layer = undefined;

  function setInformation() {
    if (layer) {
      openWidget();
      clearChildren('.flood-info-frame');
      clearChildren('.build-info-frame');
      generateComponents(layer);
    }
  }

  window.addEventListener("message", function (e) {
    if (e.source !== parent) return;

    layer = e.data.layer;
    settings = e.data.settings;
    if (settings === "") return;

    const url = settings.url;
    if (!buildings || (cachedCsvUrl !== url)) {
      d3.csv(url)
        .then((result) => {
          buildings = result;
          cachedCsvUrl = url;
          setInformation();
        });
    } else {
      setInformation();
    }
  });

  parent.postMessage({}, "*");
</script>
<div class='data-set-frame'>
  <div class="data-set">
    <details class="details">
      <summary id='flood-info-title'>浸水情報</summary>
      <div class='flood-info-frame'>
      </div>
    </details>
  </div>
  <div class="data-set">
    <details class="details">
      <summary>建物情報</summary>
      <div class='build-info-frame'>
      </div>
    </details>
  </div>
  <div>
    `
);

let settings = undefined;

function sendSelected() {
  if (reearth?.layers?.selectedFeature?.properties?.gml_id && settings?.url) {
    const properties = reearth.layers.selectedFeature.properties;
    let clone = {};

    Object.keys(properties).forEach((key) => {
      clone[key] =
        properties[key] === undefined ? "undefined" : properties[key];
    });

    console.log("clone layers: ", clone);
    reearth.ui.postMessage({
      type: "selected",
      layer: clone,
      settings: settings,
    });
  }
}

reearth.on("select", sendSelected);

let flag = false;

reearth.on("pluginmessage", (msg) => {
  if (msg.data.message !== "settings") {
    return;
  }

  settings = msg.data;
  if (!flag) {
    sendSelected();
    flag = true;
  }
});

function sendGetSettings() {
  const widget = reearth.plugins.instances.find((instance) => {
    return instance.extensionId === "building-style";
  });
  if (widget) {
    reearth.plugins.postMessage(widget.id, { message: "getSettings" });
  }
}

reearth.on("message", sendGetSettings);
reearth.on("update", sendGetSettings);
