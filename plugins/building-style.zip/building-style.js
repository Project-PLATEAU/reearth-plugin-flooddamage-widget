reearth.ui.show(
`
<style>
  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 500;
    font-display: swap;
    src: url(https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fBBc4AMP6lQ.woff2) format("woff2");
    unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA,
      U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212,
      U+2215, U+FEFF, U+FFFD;
  }

  @font-face {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    font-display: swap;
    src: url(https://fonts.gstatic.com/s/notosans/v27/o-0IIpQlx3QUlC5A4PNr5TRASf6M7Q.woff2) format("woff2");
    unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA,
      U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212,
      U+2215, U+FEFF, U+FFFD;
  }

  html,
  body {
    margin: 0;
    height: 100%;
    overflow: hidden;
    max-width: 350px;

    font-family: "Roboto";
  }

  div.menu-bar {
    width: 21px;
    height: 2px;
    background-color: #00BEBE;
    margin: 4px 0;
  }

  #wrapper {
    display: block;
    gap: 20px;
    background: #ffffff;
    overflow: hidden;
    max-width: 350px;
    height: 100%;
  }

  /* width */
  ::-webkit-scrollbar {
    width: 0px;
  }

  /* Track */
  ::-webkit-scrollbar-track {
    background: #F5F5F5;
  }

  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: #F5F5F5;
    overflow: hidden;
    max-width: 350px;
    max-height: 784px;
  }


  /* Handle on hover */
  ::-webkit-scrollbar-thumb:hover {
    background: #171618;
  }

  .section .extendedh,
  .extendedh {
    width: 180px;
    cursor: pointer;
  }

  .section .extendedv,
  .extendedv {
    height: 100%;
  }

  #wrapper {
    box-sizing: border-box;
  }

  .extendedh body,
  .extendedh #wrapper {
    width: 180px;
    border-radius: 4px;
  }

  .extendedv body,
  .extendedv #wrapper {
    max-height: 100%;
    height: 100%;
  }

  .height-46 {
    height: 46px;
    width: 180px;
    border-radius: 4px;
  }

  div#form-wrapper {
    max-width: 350px;
    background: #F5F5F5;
    padding-bottom: 15px;
    box-shadow: inset 0px 2px 8px rgb(0 0 0 / 8%);
  }

  div#map-item-wrap {
    padding: 16px;
    height: 100%;
    scrollbar-width: none;
    overflow-y: scroll;
  }

  p,
  h3,
  span,
  label {
    color: #bfbfbf;
  }

  #title {
    font-size: 14px;
    line-height: 22px;
    border-radius: 4px 4px 0px 0px;
    font-family: "Roboto";
    font-weight: 400;
    font-style: normal;
    position: relative;
    bottom: 10px;
    color: #00BEBE;
    width: 100%;
    padding-left: 24px;
    margin: 0px
  }

  p.title-p {
    margin-top: 15px;
    margin-left: 5px;
  }

  span#logo {
    position: relative;
    top: 4px;
    margin-right: 8px;
  }

  .header {
    display: inline-block;
    width: 100%;
    height: 100%;
    /* cursor: pointer; */
  }

  .header.closed {
    display: inline-block;
    width: 180px;
    cursor: pointer;
  }

  .header.closed #title,
  .header.closed #close {
    display: none;
  }

  .header.closed #title {
    display: none;
  }

  .header #title {
    display: inline-block;
  }

  .header #close {
    display: flex;
    cursor: pointer;
  }

  .header.closed #closed-title {
    display: flex;
  }

  .header #closed-title {
    display: none;
  }

  div#closed-title {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  #close {
    box-sizing: border-box;
    background-color: #00BEBE;
    display: block;
    transform: scale(var(--ggs, 1));
    width: 32px;
    height: 32px;
    border: 2px solid transparent;
    float: right;
    color: white;
    /* margin-right: 10px;
    margin-top: 15px; */
  }

  #close::after,
  #close::before {
    content: "";
    display: block;
    box-sizing: border-box;
    position: absolute;
    width: 20px;
    height: 2px;
    background: currentColor;
    transform: rotate(45deg);
    border-radius: 5px;
    top: 13px;
    left: 4px;
  }

  #close::after {
    transform: rotate(-45deg);
  }

  #closed-logo {
    display: none;
    overflow: hidden;
    width: 21px;
    height: 21px;
    cursor: pointer;
    margin-top: 11px;
    margin-left: 12px;
    background: #181618;
    padding: 5px;
    border-radius: 5px;
  }

  h3#f-title {
    font-size: 16px;
    line-height: 14px;
    border-radius: 4px 4px 0px 0px;
    font-family: "Roboto";
    font-weight: 300;
    font-style: normal;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #00BEBE;
  }

  div#menu-icon {
    margin-left: 15px;
  }

  #main {
    display: flex;
    flex-direction: column;
    padding: 12px;
    gap: 10px;
    background: var(--neutral-4, #F0F0F0);
    overflow-x: hidden;
    overflow-y: scroll;
    scroll-behavior: auto;
    height: 100%;
    margin-top: 10px;
  }

  .topography-wrapper {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 0px;
    gap: 12px;
    width: 100%;
  }

  .toggle-section {
    display: flex;
    align-items: center;
    align-self: stretch;

    background: var(--neutral-1, #FFF);


  }

  .space-btw {
    width: 88%;
    display: flex;
    justify-content: space-between;
    padding: 9px 16px;

    /* drop-shadow / button-secondary */
    border-radius: 2px;
    border: 1px solid var(--neutral-5, #D9D9D9);
    box-shadow: 0px 2px 0px 0px rgba(0, 0, 0, 0.02);
  }

  .flex-column {
    flex-direction: column;
    border-radius: 2px 2px 0px 0px;
    background: var(--neutral-1, #FFF);

  }

  .toggle-section-header {
    width: 93%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    padding: 10px;
    margin: 0;
    border-bottom: 1px solid #BFBFBF;
  }

  span.form-group {
    border-radius: 2px;
  }

  .toggle-section-header span {
    font-family: 'Roboto';
    font-weight: 100;
    font-size: 14px;
    line-height: 22px;
    display: flex;
    align-items: center;
    /* Character/Primary .85 */
    color: rgba(0, 0, 0, 0.85);
  }

  .toggle-switch {
    position: relative;
    display: inline-block;
    width: 28px;
    height: 16px;
  }

  .toggle-switch input {
    display: none;
  }

  .toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
    border-radius: 16px;
  }

  .toggle-slider:after {
    position: absolute;
    content: "";
    height: 12px;
    width: 12px;
    left: 3px;
    bottom: 2px;
    background-color: white;
    transition: .4s;
    border-radius: 50%;
  }

  input:checked+.toggle-slider {
    background-color: #00BEBE;
  }

  input:focus+.toggle-slider {
    box-shadow: 0 0 1px #00BEBE;
  }

  input:checked+.toggle-slider:after {
    transform: translateX(10px);
  }

  .toggle-section-content {
    display: none;
    overflow: hidden;
    width: 100%;
  }

  .toggle-section-content .title,
  .toggle-section-content .source {
    font-family: 'Roboto';
    /* font-style: italic; */
    font-weight: 100;
    line-height: 19px;
    /* identical to box height */

    /* Character/Title .85 */
    color: rgba(0, 0, 0, 0.85)
  }

  .toggle-section-content .title {
    justify-content: flex-start;
    font-size: 14px;
    margin-left: 8px;
  }

  .toggle-section-content .source {
    display: flex;
    justify-content: flex-end;
    margin-top: 10px;
    font-size: 12px;
  }

  .toggle-section-content-detail {
    display: flex;
    flex-direction: column;
    padding: 10px;
  }

  .toggle-section-content-detail-icon {
    display: flex;
    align-items: center;
  }

  #hidden-div {
    display: none;
  }

  span.comment {
    display: block;
    position: absolute;
    bottom: 0px;
    right: 0px;
    width: 100%;
    font-family: "Roboto" !important;
    font-style: italic;
    font-weight: 100;
    color: black;
    font-size: 12px;
    text-align: right;
    border-bottom-right-radius: 2px;
    border-bottom-left-radius: 2px;
    height: 20px;
  }

  .p-comment {
    padding: 0px 10px;
    width: fit-content;
    float: right;
    margin: 0px;
    color: #878787;
  }

  #comment {
    padding-left: 15px;
    padding-top: 15px;
    font-family: "Roboto" !important;
    font-size: 12px;
    display: flex;
    align-items: center;
  }

  #comment span {
    padding-left: 5px;
  }

  .italic-custom {
    color: rgba(0, 0, 0, 0.65)
  }

  #map-notification {
    font-family: 'Roboto';
    font-style: normal;
    font-weight: 300;
    font-size: 12px;
    line-height: 18px;
    display: flex;
    align-items: center;
    text-align: right;
    justify-content: end;
    margin-left: 40px;
    color: rgba(0, 0, 0, 0.45);
  }

  /* For scroll bar */
  #map-item-wrap::-webkit-scrollbar,
  #main::-webkit-scrollbar {
    width: 5px;
  }

  #map-item-wrap::-webkit-scrollbar-track,
  #main::-webkit-scrollbar-track {
    background-color: #f1f1f1;
  }

  #map-item-wrap::-webkit-scrollbar-thumb,
  #main::-webkit-scrollbar-thumb {
    /* Set the background color */
    background-color: #BFBFBF;
    /* Set the border radius */
    border-radius: 4px;
  }

  #main::-webkit-scrollbar-thumb,
  .general-wrapper::-webkit-scrollbar-thumb {
    background-color: #BFBFBF;
    border-radius: 4px;
  }

  .guide-comment {
    display: none;
    text-align: right;
    color: #878787;
    font-family: "Roboto";
    font-style: italic;
    font-size: 12px;
    padding-right: 10px;
    padding-bottom: 2px;
  }

  .guide-image {
    display: none;
    text-align: right;
    color: black;
    font-family: "Roboto";
    font-style: normal;
    font-size: 12px;
    background-color: #ffffffeb;
    cursor: pointer;
    padding-right: 10px;
    line-height: 22px;
  }

  /* csv handle */
  #csv-name {
    color: var(--character-title-85, rgba(0, 0, 0, 0.85));

    /* Body/regular */
    font-family: Roboto;
    font-size: 12px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  .display {
    display: flex;
    padding: 12px;
    flex-direction: column;
    align-items: flex-start;
    gap: var(--icon-normal, 16px);

    align-self: stretch;
  }

  #display-2 {
    display: none;
  }

  .tabs {
    width: 100%;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    gap: var(--radius-small, 4px);
  }

  .tab-button {
    width: 50%;
    display: flex;
    align-items: center;
    gap: 10px;
    border-radius: 2px 2px 0px 0px;
    border: none;
    background: var(--neutral-2, #FAFAFA);
    cursor: pointer;
    padding: 9px 16px;

    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    color: var(--character-primary-85, rgba(0, 0, 0, 0.85));
    /* 157.143% */
  }

  .active-tab {
    color: #00BEBE;
    background-color: #FFFFFF !important;

    color: #00BEBE;


  }

  .active-tab+.display {
    display: block;
  }

  .count-sum {
    display: flex;
    align-items: flex-start;
    gap: 24px;
    align-self: stretch;
  }

  .sum {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 4px;
    flex: 1 0 0;
  }

  .dot {
    height: 6px;
    width: 6px;
    border-radius: 50%;
    display: inline-block;
  }

  #sum-color-1,
  #machi-color-1 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    border-radius: 100px;
    background: var(--dust-red-5, #FF4D4F);
  }

  #sum-color-2,
  #machi-color-2 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    border-radius: 100px;
    background: #40A9FF;
  }

  #detail-color-1,
  #detail-machi-color-1 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    border-radius: 100px;
    background: #0000FF;
  }

  #detail-color-2,
  #detail-machi-color-2 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    border-radius: 100px;
    background: #00FFFF;
  }

  #detail-color-3,
  #detail-machi-color-3 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    border-radius: 100px;
    background: #FA0000;
  }

  #detail-color-4,
  #detail-machi-color-4 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    border-radius: 100px;
    background: #FFB8E5;
  }

  #detail-color-5,
  #detail-machi-color-5 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    border-radius: 100px;
    background: #FFFF00;
  }

  #detail-color-6,
  #detail-machi-color-6 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    border-radius: 100px;
    background: #8B4513;
  }

  #detail-color-9,
  #detail-machi-color-9 {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    border-radius: 100px;
    background: #9370DB;
  }

  .sum-title {
    color: var(--character-primary-85, rgba(0, 0, 0, 0.85));

    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  .sum-number {
    color: var(--character-title-85, rgba(0, 0, 0, 0.85));
    font-family: Roboto;
    font-size: 24px;
    font-style: normal;
    font-weight: 400;
    line-height: 28px;
    /* 116.667% */
  }

  .flex-row {
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 8px;
  }

  .count-detail-title {
    display: flex;
    color: #000;
    text-align: center;
    font-feature-settings: 'clig' off, 'liga' off;

    line-height: normal;
    justify-content: flex-start;

    /* EN/S/Bold */
    font-family: "Roboto";
    font-size: 14px;
    font-style: normal;
    font-weight: 700;
    line-height: normal;
  }

  .count-detail {
    gap: 16px;
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
  }

  .detail-elm {
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 8px;
  }

  .detail-number,
  .detail-title {
    color: var(--character-primary-85, rgba(0, 0, 0, 0.85));

    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  .w-126 {
    width: 126px;
  }

  .count-detail-section {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
    align-self: stretch;
  }

  /* dropdown */
  .dropbtn {
    cursor: pointer;
  }

  .dropdown {
    position: relative;
    display: inline-block;
  }

  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    z-index: 1;

    max-height: 200px;
    scroll-behavior: auto;
    overflow-y: scroll;
  }

  .w-302 {
    width: 302px;
    min-width: 300px;
    top: 55px;

  }

  .w-297 {
    width: 297px;
    min-width: 295px;
  }

  .dropdown-content span {
    color: var(--character-primary-85, rgba(0, 0, 0, 0.85));
    padding: 5px 12px;
    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
    text-decoration: none;
    display: block;
  }

  .dropdown-content span:hover {
    background: var(--cyan-1, #E6FFFB);
  }

  /* .dropdown:hover .dropdown-content {
    display: block;
  } */

  /* display-2 */
  #display-2 {
    display: none;
    /* height: 423px; */
    flex-direction: column;
    justify-content: center;
    align-items: center;
    align-self: stretch;
    background: var(--neutral-1, #FFF);
  }

  #no-address {
    display: flex;
    height: 391px;
    align-items: center;
  }

  #with-address {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    width: 100%;
    gap: 16px;
  }

  /* address  */
  .address-title {
    display: flex;
    padding: 12px;
    flex-direction: column;
    align-items: flex-start;
    align-self: stretch;
    border-bottom: 1px solid #E0E0E0;

    flex: 1 0 0;
    color: var(--character-primary-85, rgba(0, 0, 0, 0.85));
    font-feature-settings: 'clig' off, 'liga' off;
    /* EN/M/medium */
    /* font-family: Noto Sans; */
    font-size: 16px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
  }

  #address-picker {
    display: flex;
    flex-direction: column;
    /* align-items: flex-end; */
    gap: 12px;
    align-self: stretch;
  }

  .address-dropdown-title {
    border: none;
    color: var(--character-secondary-45, rgba(0, 0, 0, 0.45));

    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  #searchInput:focus,
  #color-hex-1:focus,
  #color-hex-2:focus,
  #color-hex-3:focus,
  #color-hex-5:focus,
  #color-hex-6:focus,
  #color-hex-7:focus,
  #color-hex-9:focus {
    outline: none;
    border: none;
    /* or you could set it to 'border: 1px solid transparent;' if you need to maintain box size */
  }



  #picked-content-address {
    display: flex;
    flex-direction: column;
    gap: 1px;
    max-height: 100px;
    overflow-y: scroll;
    scroll-behavior: smooth;
  }

  .picked-elm {
    display: flex;
    padding: var(--radius-normal, 6px) var(--icon-normal, 16px);
    justify-content: space-between;
    align-items: center;
    align-self: stretch;

    border-radius: var(--spacing-micro, 2px);
    background: var(--neutral-color-palette-2, #FAFAFA);
  }

  .picked-elm-title {
    color: var(--character-primary-85, rgba(0, 0, 0, 0.85));

    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  .picked-elm-button-group {
    display: flex;
    flex-direction: row;
    gap: var(--radius-normal, 6px);
  }

  .picked-btn {
    cursor: pointer;
  }

  #button-control-address,
  .gr-btn {
    display: flex;
    flex-direction: row;
    width: 100%;
    gap: 6px;
  }

  .btn {
    display: flex;
    padding: 8px 16px;
    /* flex-direction: column; */
    justify-content: center;
    align-items: center;
    gap: 8px;
    flex: 1 0 0;
    cursor: pointer;

    color: var(--character-primary-inverse, #FFF);
    text-align: center;

    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  .primary {
    border-radius: 4px;
    border: 1px solid #00BEBE;
    background: #00BEBE;
    color: var(--character-primary-inverse, #FFF);

    /* drop-shadow / button-primary */
    box-shadow: 0px 2px 0px 0px rgba(0, 0, 0, 0.04);
  }

  .secondary {
    border-radius: 4px;
    border: 1px solid var(--neutral-5, #D9D9D9);
    background: var(--neutral-1, #FFF);
    color: var(--character-title-85, rgba(0, 0, 0, 0.85));

    /* drop-shadow / button-secondary */
    box-shadow: 0px 2px 0px 0px rgba(0, 0, 0, 0.02);
  }

  /* ---style building ---  */
  #style-bld-section {
    display: flex;
    padding: 12px;
    flex-direction: column;
    align-items: flex-end;
    gap: 24px;
    align-self: stretch;
  }

  .style-bld-wrapper {
    display: flex;
    justify-content: flex-end;
    align-items: flex-start;
    flex-direction: row;
    gap: 24px;
    align-self: stretch;
  }

  .style-checkbox {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    /* gap: 12px; */
    flex: 1 0 0;
    width: 173px;
  }

  .level2 {
    display: flex;
    gap: 12px;
  }

  .level2-checkbox {
    display: flex;
    padding-left: 0px;
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
    margin-top: 12px;
    align-self: stretch;
  }

  .level3 {
    display: flex;
    gap: 12px;
  }

  .level3-checkbox {
    display: flex;
    padding-left: 0px;
    flex-direction: column;
    align-items: flex-start;
    margin-top: 12px;
    gap: 20px;
    align-self: stretch;
  }

  .style-color {
    display: flex;
    padding-top: 58px;
    flex-direction: column;
    align-items: flex-start;
    gap: 30px;
    width: 105px;
  }

  .cb-container {
    width: 100%;
    display: flex;
    flex-direction: row;
    gap: 4px;
    align-items: center;

    color: var(--character-title-85, rgba(0, 0, 0, 0.85));

    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  .color-container {
    display: flex;
    align-items: center;
    flex: 1 0 0;
    height: 30px;
    flex-direction: row;
    align-self: stretch;
    border: 1px solid #D9D9D9;

  }

  .second {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    /* gap: 12px; */
    align-self: stretch;
  }

  .dotted {
    margin-left: 9px;
  }

  hr {
    border: 1px solid #D9D9D9;
  }

  .color-css {
    display: flex;
    width: 105px;
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }

  input[type="color"] {
    border: none;
    border-radius: var(--radius-small, 4px);
    height: 30px;
    padding: 0px;
    margin: 0px;
  }

  input[type="color"]::-webkit-color-swatch {
    border: none;
  }

  input[type="color"]::-webkit-color-swatch-wrapper {
    padding: 0;
  }

  input[type="checkbox"] {
    border: none;
  }

  .input-container {
    align-items: center;
    display: flex;
    height: 28px;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    color: var(--character-title-85, rgba(0, 0, 0, 0.85));
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 18px;
    padding-left: 7px;
    border: none;
    /* 128.571% */
  }

  /* ---opacity slider---  */
  .opacity {
    display: flex;
    align-items: center;
    gap: 12px;
    align-self: stretch;
  }

  .opacity-title {
    color: var(--character-title-85, rgba(0, 0, 0, 0.85));
    min-width: 56px;
    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  .opacity-slider {
    width: 100%;
  }

  .slider {
    -webkit-appearance: none;
    width: 100%;
    height: 25px;
    background: #FFFFFF;
    outline: none;
    opacity: 0.8;
  }

  .slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 25px;
    height: 25px;
    border: 1px solid #91D5FF;
    background: #FFFFFF;
    cursor: pointer;
  }

  .slider::-moz-range-thumb {
    width: 25px;
    height: 25px;
    border: 1px solid #91D5FF;
    background: #FFFFFF;
    cursor: pointer;
  }

  .full-slider {
    width: 100%;
    padding-top: 1px;
  }

  input[type="range"] {
    width: 99%;
    background: #91D5FF;
  }

  /* --download btn--- */
  .dwl-btn {
    display: flex;
    /* padding: 12px; */
    flex-direction: column;
    align-items: flex-end;
    gap: 10px;
    align-self: stretch;
  }

  .primary-bg-important {
    background: var(--neutral-4, #F0F0F0) !important;
  }

  .dwl-text {
    color: var(--character-title-85, rgba(0, 0, 0, 0.85));
  }

  #download-btn {}

  .show {
    display: block !important;
    /* '!important' to ensure it overrides any other 'display' property */
  }

  .active-address {
    background-color: #E6FFFB;
    position: relative;
  }

  .active-address::after {
    content: '';
    display: block;
    width: 12px;
    /* Width of your SVG icon */
    height: 12px;
    /* Height of your SVG icon */
    background-image: url("data:image/svg+xml,%3Csvg width='12' height='12' viewBox='0 0 12 12' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11.3578 1.6875H10.4216C10.2904 1.6875 10.1658 1.74777 10.0855 1.85089L4.56358 8.84598L1.91581 5.49107C1.87576 5.44022 1.82471 5.3991 1.76648 5.3708C1.70826 5.3425 1.64439 5.32776 1.57965 5.32768H0.643492C0.55376 5.32768 0.504207 5.4308 0.559117 5.50045L4.22742 10.1478C4.39885 10.3647 4.72831 10.3647 4.90108 10.1478L11.4422 1.85893C11.4971 1.79063 11.4475 1.6875 11.3578 1.6875Z' fill='%2300BEBE'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: center;
    position: absolute;
    left: 272px;
    top: 50%;
    transform: translateY(-50%);
  }

  .csv-wrapper {
    display: flex;
    width: 326px;
    flex-direction: column;
    align-items: flex-start;

    border-radius: var(--radius-small, 4px);
    background: var(--neutral-1, #FFF);

    /* drop-shadow / 0.15 */
    box-shadow: 0px 2px 8px 0px rgba(0, 0, 0, 0.15);
  }

  .csv-wrapper-title {
    display: flex;
    padding: 12px;
    flex-direction: column;
    align-items: flex-start;
    align-self: stretch;
    color: var(--character-primary-85, rgba(0, 0, 0, 0.85));
    font-feature-settings: 'clig' off, 'liga' off;

    /* EN/M/medium */
    font-family: Roboto;
    font-size: 16px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;

    border-bottom: 1px solid #E0E0E0;
  }

  #csv-section {
    display: flex;
    padding: 12px;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    align-self: stretch;
  }

  /* .active-camera svg path {
    stroke: #00BEBE;
  } */

  .hanrei-text {
    display: flex;
    padding: 12px 12px 0 12px;
    justify-content: flex-start;
    width: 91%;
  }

  .active-highlight svg path {
    stroke: #00BEBE;
  }

  .disabled-btn {
    display: flex;
    padding: 8px 16px;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    flex: 1 0 0;
    cursor: not-allowed;
    pointer-events: none;

    border-radius: 4px;
    border: 1px solid var(--neutral-5, #D9D9D9);
    background: var(--neutral-3, #F5F5F5);

    /* drop-shadow / button-secondary */
    box-shadow: 0px 2px 0px 0px rgba(0, 0, 0, 0.02);

    color: var(--character-disabled-placeholder-25, rgba(0, 0, 0, 0.25));
    text-align: center;

    /* Body/regular */
    font-family: Roboto;
    font-size: 14px;
    font-style: normal;
    font-weight: 400;
    line-height: 22px;
    /* 157.143% */
  }

  /* --end style--- */
</style>
<div class="height-46" id="wrapper">
  <div class="header closed" id="header">
    <span id="close"></span>
    <div id="closed-title">
      <h3 id="f-title">
        建築物被災情報
      </h3>
      <div id="menu-icon">
        <div class="menu-bar"></div>
        <div class="menu-bar"></div>
        <div class="menu-bar"></div>
      </div>

    </div>
    <h3 id="title">
      建築物被災情報
    </h3>
    <div id="main">
      <div class="topography-wrapper">

        <!-- 1st section  -->
        <div class="csv-wrapper">
          <div class="csv-wrapper-title">
            衛星画像の取得日時
          </div>
          <div class="toggle-section dropdown" id="csv-section">
            <div class="space-btw dropbtn" id="dropdown-1">
              <div id="csv-name">
                衛星名-日時
              </div>
              <div id="csv-down-arr">
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none">
                  <path
                    d="M9.15179 3.51797H8.31473C8.25781 3.51797 8.20424 3.54588 8.17076 3.59164L5 7.96217L1.82924 3.59164C1.79576 3.54588 1.74219 3.51797 1.68527 3.51797H0.848216C0.775671 3.51797 0.733261 3.60056 0.775671 3.65972L4.71094 9.08494C4.8538 9.28137 5.14621 9.28137 5.28795 9.08494L9.22322 3.65972C9.26674 3.60056 9.22433 3.51797 9.15179 3.51797Z"
                    fill="black" fill-opacity="0.85" />
                </svg>
              </div>
            </div>
            <div class="dropdown-content w-302" id="dropdown-content-1">

            </div>

          </div>
        </div>

        <!-- end 1st section  -->

        <!-- 2nd section  -->
        <div class="toggle-section flex-column" id="building-section">
          <div class="tabs">
            <button class="tab-button active-tab" id="tab-1">
              自治体被災建物件数</button>
            <button class="tab-button" id="tab-2">
              町丁目被災建物件数</button>
          </div>

          <!-- show tab 1 -->
          <div id="display-1" class="display">

            <!-- count-sum  -->
            <div class="count-sum">
              <div id="sum-all-1" class="sum">
                <div class="flex-row">
                  <span id="sum-color-1" class="dot"></span>
                  <span class="sum-title">被災建物総数</span>
                </div>
                <span class="sum-number" id="all-damage-building">0</span>
              </div>

              <div id="sum-all-2" class="sum">
                <div class="flex-row">
                  <span id="sum-color-2" class="dot"></span>
                  <span class="sum-title">建物総数</span>
                </div>
                <span class="sum-number" id="all-building">0</span>
              </div>
            </div>

            <!-- count-detail-section  -->
            <div class="count-detail-section">
              <!-- count-detail-title -->
              <div class="count-detail-title">
                各被災カテゴリごと
              </div>

              <!-- count-detail  -->
              <div class="count-detail">
                <!-- detail-1 -->
                <div class="detail-elm" id="detail-all-1">
                  <div class="flex-row w-126">
                    <span id="detail-color-1" class="dot"></span>
                    <span class="detail-title">床上（木造）</span>
                  </div>
                  <div id="detail-number-1" class="detail-number">
                    0/0
                  </div>
                </div>

                <!-- detail-2 -->
                <div class="detail-elm" id="detail-all-2">
                  <div class="flex-row w-126">
                    <span id="detail-color-2" class="dot"></span>
                    <span class="detail-title">床下（木造）</span>
                  </div>
                  <div id="detail-number-2" class="detail-number">
                    0/0
                  </div>
                </div>

                <!-- detail-3 -->
                <div class="detail-elm" id="detail-all-3">
                  <div class="flex-row w-126">
                    <span id="detail-color-3" class="dot"></span>
                    <span class="detail-title">床上（レンガ造）</span>
                  </div>
                  <div id="detail-number-3" class="detail-number">
                    0/0
                  </div>
                </div>

                <!-- detail-4 -->
                <div class="detail-elm" id="detail-all-4">
                  <div class="flex-row w-126">
                    <span id="detail-color-4" class="dot"></span>
                    <span class="detail-title">床下（レンガ造）</span>
                  </div>
                  <div id="detail-number-4" class="detail-number">
                    0/0
                  </div>
                </div>

                <!-- detail-5 -->
                <div class="detail-elm" id="detail-all-5">
                  <div class="flex-row w-126">
                    <span id="detail-color-5" class="dot"></span>
                    <span class="detail-title">床上（不明）</span>
                  </div>
                  <div id="detail-number-5" class="detail-number">
                    0/0
                  </div>
                </div>

                <!-- detail-6 -->
                <div class="detail-elm" id="detail-all-6">
                  <div class="flex-row w-126">
                    <span id="detail-color-6" class="dot"></span>
                    <span class="detail-title">床下（不明）</span>
                  </div>
                  <div id="detail-number-6" class="detail-number">
                    0/0
                  </div>
                </div>

                <!-- detail-9 -->
                <div class="detail-elm" id="detail-all-9">
                  <div class="flex-row w-126">
                    <span id="detail-color-9" class="dot"></span>
                    <span class="detail-title">浸水（非木造）</span>
                  </div>
                  <div id="detail-number-9" class="detail-number">
                    0/0
                  </div>
                </div>

                <!-- ---   -->
              </div>
            </div>


          </div>

          <!-- show tab 2 -->
          <div id="display-2" class="display">
            <!-- address picker -->
            <div id="address-picker">

              <!-- --- dropdown pick address--- -->
              <div class="dropdown" id="dropdown-pick-address">
                <div class="space-btw dropbtn" id="dropdown-2">
                  <input type="text" placeholder="地域を検索" id="searchInput" class="address-dropdown-title">
                  <div id="address-down-arr">
                    <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none">
                      <path
                        d="M9.15179 3.51797H8.31473C8.25781 3.51797 8.20424 3.54588 8.17076 3.59164L5 7.96217L1.82924 3.59164C1.79576 3.54588 1.74219 3.51797 1.68527 3.51797H0.848216C0.775671 3.51797 0.733261 3.60056 0.775671 3.65972L4.71094 9.08494C4.8538 9.28137 5.14621 9.28137 5.28795 9.08494L9.22322 3.65972C9.26674 3.60056 9.22433 3.51797 9.15179 3.51797Z"
                        fill="black" fill-opacity="0.85" />
                    </svg>
                  </div>
                </div>
                <div class="dropdown-content w-297" id="dropdown-content-2">
                  <!-- <span id="check-all-address">すべて</span> -->
                </div>

              </div>

              <!-- --- picked content address --- -->
              <div id="picked-content-address">
              </div>

              <!-- --- button control address--- -->
              <div id="button-control-address" class="gr-btn">
                <button id="remove-highlight-btn" class="btn secondary disabled-btn">
                  ハイライトの削除
                </button>

                <button id="highlight-btn" class="btn secondary disabled-btn">
                  全てハイライト
                </button>
              </div>


            </div>

            <!-- without address -->
            <!-- <div id="no-address">
              下の地域を選択してください。
            </div> -->

            <!-- with-address -->
            <div id="with-address">

              <!-- count-sum  -->
              <div class="count-sum">
                <div id="sum-machi-1" class="sum">
                  <div class="flex-row">
                    <span id="machi-color-1" class="dot"></span>
                    <span class="sum-title">被災建物総数</span>
                  </div>
                  <span class="sum-number" id="all-machi-damage">0</span>
                </div>

                <div id="sum-machi-2" class="sum">
                  <div class="flex-row">
                    <span id="machi-color-2" class="dot"></span>
                    <span class="sum-title">建物総数</span>
                  </div>
                  <span class="sum-number" id="all-machi-building">0</span>
                </div>
              </div>

              <!-- count-detail-section  -->
              <div class="count-detail-section">
                <!-- count-detail-title -->
                <div class="count-detail-title">
                  各被災カテゴリごと
                </div>

                <!-- count-detail  -->
                <div class="count-detail">
                  <!-- detail-1 -->
                  <div class="detail-elm" id="detail-machi-1">
                    <div class="flex-row w-126">
                      <span id="detail-machi-color-1" class="dot"></span>
                      <span class="detail-title">床上（木造）</span>
                    </div>
                    <div id="detail-machi-number-1" class="detail-number">
                      0/0
                    </div>
                  </div>

                  <!-- detail-2 -->
                  <div class="detail-elm" id="detail-machi-2">
                    <div class="flex-row w-126">
                      <span id="detail-machi-color-2" class="dot"></span>
                      <span class="detail-title">床下（木造）</span>
                    </div>
                    <div id="detail-machi-number-2" class="detail-number">
                      0/0
                    </div>
                  </div>

                  <!-- detail-3 -->
                  <div class="detail-elm" id="detail-machi-3">
                    <div class="flex-row w-126">
                      <span id="detail-machi-color-3" class="dot"></span>
                      <span class="detail-title">床上（レンガ造）</span>
                    </div>
                    <div id="detail-machi-number-3" class="detail-number">
                      0/0
                    </div>
                  </div>

                  <!-- detail-4 -->
                  <div class="detail-elm" id="detail-machi-4">
                    <div class="flex-row w-126">
                      <span id="detail-machi-color-4" class="dot"></span>
                      <span class="detail-title">床下（レンガ造）</span>
                    </div>
                    <div id="detail-machi-number-4" class="detail-number">
                      0/0
                    </div>
                  </div>

                  <!-- detail-5 -->
                  <div class="detail-elm" id="detail-machi-5">
                    <div class="flex-row w-126">
                      <span id="detail-machi-color-5" class="dot"></span>
                      <span class="detail-title">床上（不明）</span>
                    </div>
                    <div id="detail-machi-number-5" class="detail-number">
                      0/0
                    </div>
                  </div>

                  <!-- detail-6 -->
                  <div class="detail-elm" id="detail-machi-6">
                    <div class="flex-row w-126">
                      <span id="detail-machi-color-6" class="dot"></span>
                      <span class="detail-title">床下（不明）</span>
                    </div>
                    <div id="detail-machi-number-6" class="detail-number">
                      0/0
                    </div>
                  </div>



                  <!-- detail-9 -->
                  <div class="detail-elm" id="detail-machi-9">
                    <div class="flex-row w-126">
                      <span id="detail-machi-color-9" class="dot"></span>
                      <span class="detail-title">浸水（非木造）</span>
                    </div>
                    <div id="detail-machi-number-9" class="detail-number">
                      0/0
                    </div>
                  </div>

                  <!-- ---   -->
                </div>
              </div>
            </div>

          </div>

        </div>
        <!-- end 2nd section  -->

        <!-- 3rd section  -->
        <div class="toggle-section flex-column" id="address-section">
          <div class="address-title">
            スタイリング
          </div>

          <!-- style section  -->
          <div id="style-bld-section">

            <!-- --- select condition and color---  -->
            <div class="style-bld-wrapper">

              <div class="style-checkbox">

                <div class="check-all-checkbox cb-container">
                  <input type="checkbox" name="" id="check-all">
                  <div type="text" id="value-check-all" class="">
                    すべて
                  </div>
                </div>

                <div class="level2">
                  <hr class="dotted">

                  <div class="level2-checkbox">
                    <div class="second">

                      <div class="cb-container">
                        <input type="checkbox" name="" id="check-3-1">
                        <div type="text" class="">
                          床上
                        </div>
                      </div>

                      <div class="level3">
                        <hr class="dotted">
                        <div class="level3-checkbox">
                          <div class="cb-container">
                            <input type="checkbox" name="" id="check-31">
                            <div type="text" id="value-check-31" class="">
                              木造
                            </div>
                          </div>

                          <div class="cb-container">
                            <input type="checkbox" name="" id="check-32">
                            <div type="text" id="value-check-32" class="">
                              レンガ造
                            </div>
                          </div>

                          <div class="cb-container">
                            <input type="checkbox" name="" id="check-33">
                            <div type="text" id="value-check-33" class="">
                              不明
                            </div>
                          </div>

                        </div>
                      </div>


                    </div>


                    <div class="second">
                      <div class="cb-container">
                        <input type="checkbox" name="" id="check-3-2">
                        <div type="text" id="value-check-all" class="">
                          床下
                        </div>
                      </div>

                      <div class="level3">
                        <hr class="dotted">
                        <div class="level3-checkbox">
                          <div class="cb-container">
                            <input type="checkbox" name="" id="check-35">
                            <div type="text" id="value-check-35" class="">
                              木造
                            </div>
                          </div>

                          <div class="cb-container">
                            <input type="checkbox" name="" id="check-36">
                            <div type="text" id="value-check-36" class="">
                              レンガ造
                            </div>
                          </div>

                          <div class="cb-container">
                            <input type="checkbox" name="" id="check-37">
                            <div type="text" id="value-check-37" class="">
                              不明
                            </div>
                          </div>

                        </div>
                      </div>

                    </div>

                    <div class="second">
                      <div class="cb-container">
                        <input type="checkbox" name="" id="check-3-3">
                        <div type="text" class="">
                          浸水
                        </div>
                      </div>

                      <div class="level3">
                        <hr class="dotted">
                        <div class="level3-checkbox">
                          <div class="cb-container">
                            <input type="checkbox" name="" id="check-39">
                            <div type="text" id="value-check-39" class="">
                              非木造
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>

                  </div>


                </div>



              </div>

              <div class="style-color">

                <div class="color-css">
                  <div class="color-container">
                    <input type="color" value="#0000FF" id="color-value-1" name="" />
                    <input class="hex-color input-container" type="text" id="color-hex-1" value="#0000FF">
                  </div>

                  <div class="color-container">
                    <input type="color" value="#FA0000" id="color-value-2" name="" />
                    <input class="hex-color input-container" type="text" id="color-hex-2" value="#FA0000">
                  </div>

                  <div class="color-container">
                    <input type="color" value="#FFFF00" id="color-value-3" name="" />
                    <input class="hex-color input-container" type="text" id="color-hex-3" value="#FFFF00">
                  </div>

                </div>

                <div class="color-css">
                  <div class="color-container">
                    <input type="color" value="#00FFFF" id="color-value-5" name="" />
                    <input class="hex-color input-container" type="text" id="color-hex-5" value="#00FFFF">
                  </div>

                  <div class="color-container">
                    <input type="color" value="#FFB8E5" id="color-value-6" name="" />
                    <input class="hex-color input-container" type="text" id="color-hex-6" value="#FFB8E5">
                  </div>

                  <div class="color-container">
                    <input type="color" value="#8B4513" id="color-value-7" name="" />
                    <input class="hex-color input-container" type="text" id="color-hex-7" value="#8B4513">
                  </div>

                </div>

                <div class="color-css">
                  <div class="color-container">
                    <input type="color" value="#9370DB" id="color-value-9" name="" />
                    <input class="hex-color input-container" type="text" id="color-hex-9" value="#9370DB">
                  </div>
                </div>


              </div>
            </div>

            <!-- --- select opacity ---  -->
            <div class="opacity">
              <div class="opacity-title">
                不透明度
              </div>
              <div class="full-slider">
                <div class="slider">
                  <input type="range" min="0" max="10" value="10" id="opacity-slider">
                </div>
              </div>

            </div>


            <!-- --- style button group --- -->
            <div id="button-control-style" class="gr-btn">
              <button id="remove-style-btn" class="btn secondary">
                スタイルの削除
              </button>

              <button id="apply-style-btn" class="btn primary">
                スタイルの適用
              </button>
            </div>

          </div>

        </div>
        <!-- end 3rd section  -->

        <!-- 4th section  -->
        <div class="toggle-section flex-column primary-bg-important">
          <div class="dwl-btn">
            <button id="download-btn" class="btn secondary">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                <path
                  d="M6.90156 9.32544C6.91326 9.34038 6.92819 9.35246 6.94525 9.36077C6.96231 9.36908 6.98103 9.3734 7 9.3734C7.01897 9.3734 7.03769 9.36908 7.05475 9.36077C7.0718 9.35246 7.08674 9.34038 7.09844 9.32544L8.84844 7.11138C8.9125 7.03013 8.85469 6.90981 8.75 6.90981H7.59219V1.62231C7.59219 1.55356 7.53594 1.49731 7.46719 1.49731H6.52969C6.46094 1.49731 6.40469 1.55356 6.40469 1.62231V6.90825H5.25C5.14531 6.90825 5.0875 7.02857 5.15156 7.10982L6.90156 9.32544ZM12.7188 8.77857H11.7812C11.7125 8.77857 11.6562 8.83482 11.6562 8.90357V11.3098H2.34375V8.90357C2.34375 8.83482 2.2875 8.77857 2.21875 8.77857H1.28125C1.2125 8.77857 1.15625 8.83482 1.15625 8.90357V11.9973C1.15625 12.2739 1.37969 12.4973 1.65625 12.4973H12.3438C12.6203 12.4973 12.8438 12.2739 12.8438 11.9973V8.90357C12.8438 8.83482 12.7875 8.77857 12.7188 8.77857Z"
                  fill="black" fill-opacity="0.85" />
              </svg>
              <span class="dwl-text">ダウンロード</span>
            </button>
          </div>

        </div>
        <!-- end 4th section  -->


      </div>
    </div>

  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
  <script src="https://cdn.jsdelivr.net/npm/@turf/turf@6/turf.min.js"></script>

  <script>
    let expanded = false;
    let headerElm = document.getElementById("header");
    let wrapperElm = document.getElementById("wrapper");
    let heightWp = window.screen.height;
    let reearth;
    let property;

    const withAddressDiv = document.getElementById("with-address");
    const noAddressDiv = document.getElementById("no-address");
    const allMachiDamageBuilding = document.getElementById("all-machi-damage");
    const allMachiBuilding = document.getElementById("all-machi-building");
    const detailMachiNum1 = document.getElementById("detail-machi-number-1");
    const detailMachiNum2 = document.getElementById("detail-machi-number-2");
    const detailMachiNum3 = document.getElementById("detail-machi-number-3");
    const detailMachiNum4 = document.getElementById("detail-machi-number-4");
    const detailMachiNum5 = document.getElementById("detail-machi-number-5");
    const detailMachiNum6 = document.getElementById("detail-machi-number-6");
    const detailMachiNum9 = document.getElementById("detail-machi-number-9");


    // Call the initialization method to start the app
    init();
    parent.postMessage({ action: "initWidget", }, "*");


    async function init() {
      headerElm.addEventListener("click", handleCloseOpenPopup);
      headerElm.click();
      displayDefaultTab();
      document.getElementById("searchInput").addEventListener("input", filterFunction);

    }

    function displayDefaultTab() {
      const tabButtons = document.querySelectorAll('.tab-button');

      // add active class to the first tab button by default
      const displays = document.querySelectorAll('.display');

      // Show the content of Tab 1 by default
      document.querySelector('#display-1').style.display = 'flex';

      tabButtons.forEach(tab => {
        tab.addEventListener('click', (e) => {
          e.stopPropagation();
          // remove active class from all tabs
          tabButtons.forEach(tb => tb.classList.remove('active-tab'));

          // add active class to clicked tab
          tab.classList.add('active-tab');

          // // show data of the clicked tab and hide other tab
          const displayId = tab.id.replace('tab-', 'display-');

          displays.forEach(display => {
            if (display.id === displayId) {
              display.style.display = 'flex';
            } else {
              display.style.display = 'none';
            }
          })

        });
      });
    }

    function updateIframeSize() {
      expanded = false;
      heightWp = document.getElementById("wrapper").offsetHeight;
      parent.postMessage({ type: "resize", expanded, heightWp }, "*");
    }


    function handleCloseOpenPopup(e) {
      // Handle when clicking to open popup
      let header = document.getElementById("header");
      if (e.target.id == "menu-icon" || e.target.id == "closed-title" || e.target.id == "header" || e.target.id == "f-title" || e.target.classList.contains("menu-bar") ||
        (document.getElementById(e.target.id) !== null && document.getElementById(e.target.id).parentNode.id == "closed-title")) {

        if (wrapperElm !== null) {
          wrapperElm.classList.remove("height-46");
        }
        wrapperElm.style.height = heightWp
        header.classList.remove("closed");
        parent.postMessage({ type: "resize", expanded, heightWp: heightWp }, "*");
      } else {
        // Handle clicking to close popup
        if (e.target.id === "close") {
          parent.postMessage({ type: "resize", expanded: true, heightWp: "100%" }, "*");
          wrapperElm.style.height = "100%"
          header.classList.add("closed");
          parent.postMessage({ type: "closePopup" }, "*");
        }
      }
    }

    // Filter function for search input
    function filterFunction() {
      var input, filter, dropdown, span, i;
      input = document.getElementById("searchInput");
      filter = input.value.toUpperCase();
      dropdown = document.getElementById("dropdown-content-2");
      span = dropdown.getElementsByTagName("span");
      for (i = 0; i < span.length; i++) {
        txtValue = span[i].textContent || span[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          span[i].style.display = "";
        } else {
          span[i].style.display = "none";
        }
      }
    }


    // Dropdown handler
    function setupDropdown(dropdownId, contentId) {
      const dropdown = document.getElementById(dropdownId);
      const content = document.getElementById(contentId);

      if (!dropdown || !content) return;
      dropdown.onclick = () => content.classList.toggle('show');
    }

    setupDropdown('dropdown-1', 'dropdown-content-1');
    setupDropdown('dropdown-2', 'dropdown-content-2');

    // Utility function to set the checked state of a list of checkboxes
    function setCheckboxes(checkboxes, state) {
      checkboxes.forEach((checkbox) => {
        if (checkbox) checkbox.checked = state;
      });
    }

    // Function to check if all checkboxes in a group are checked
    function areAllChecked(checkboxes) {
      return checkboxes.every(checkbox => checkbox && checkbox.checked);
    }

    // Function to update group 'check all' checkboxes
    function updateGroupCheckbox(masterCheckbox, checkboxes) {
      masterCheckbox.checked = areAllChecked(checkboxes);
    }

    // Function to update the master 'check all' checkbox
    function updateMasterCheckbox() {
      const allGroups = [checkboxesGroup1, checkboxesGroup2, checkboxesGroup3];
      checkboxAll.checked = allGroups.every(group => areAllChecked(group));
    }

    // Add event listener to a checkbox to manage children checkboxes
    function setupParentCheckbox(parentCheckbox, childCheckboxes) {
      parentCheckbox.addEventListener('change', (event) => {
        setCheckboxes(childCheckboxes, event.target.checked);
        updateMasterCheckbox();
      });
    }

    // Add event listeners to children checkboxes to update their parent and master
    function setupChildCheckboxes(parentCheckbox, childCheckboxes) {
      childCheckboxes.forEach((checkbox) => {
        checkbox.addEventListener('change', () => {
          updateGroupCheckbox(parentCheckbox, childCheckboxes);
          updateMasterCheckbox();
        });
      });
    }

    // Get all checkboxes
    const checkboxAll = document.getElementById('check-all');
    const checkbox3all1 = document.getElementById("check-3-1");
    const checkbox3all2 = document.getElementById("check-3-2");
    const checkbox3all3 = document.getElementById("check-3-3");
    const checkbox31 = document.getElementById("check-31");
    const checkbox32 = document.getElementById("check-32");
    const checkbox33 = document.getElementById("check-33");
    const checkbox35 = document.getElementById("check-35");
    const checkbox36 = document.getElementById("check-36");
    const checkbox37 = document.getElementById("check-37");
    const checkbox39 = document.getElementById("check-39");

    const checkboxesGroup1 = [checkbox31, checkbox32, checkbox33];
    const checkboxesGroup2 = [checkbox35, checkbox36, checkbox37];
    const checkboxesGroup3 = [checkbox39];

    // Function to initialize all checkboxes to checked
    function initializeCheckboxes() {
      const allCheckboxes = [
        checkboxAll,
        checkbox3all1,
        checkbox3all2,
        checkbox3all3,
        ...checkboxesGroup1,
        ...checkboxesGroup2,
        ...checkboxesGroup3
      ];

      // Set all individual checkboxes to checked
      setCheckboxes(allCheckboxes, true);

      // Since all checkboxes are initialized as checked, set the master checkbox to checked
      checkboxAll.checked = true;
    }


    // Setup event listeners for the 'check all' checkbox
    checkboxAll.addEventListener('change', (event) => {
      [checkbox3all1, checkbox3all2, checkbox3all3, ...checkboxesGroup1, ...checkboxesGroup2, ...checkboxesGroup3].forEach(chk => {
        if (chk) chk.checked = event.target.checked;
      });
    });

    // Setup parent-child relationships
    setupParentCheckbox(checkbox3all1, checkboxesGroup1);
    setupParentCheckbox(checkbox3all2, checkboxesGroup2);
    setupParentCheckbox(checkbox3all3, checkboxesGroup3);

    // Setup child-parent relationships
    setupChildCheckboxes(checkbox3all1, checkboxesGroup1);
    setupChildCheckboxes(checkbox3all2, checkboxesGroup2);
    setupChildCheckboxes(checkbox3all3, checkboxesGroup3);

    // Initialize all checkboxes
    initializeCheckboxes();


    const removeStyleBtn = document.getElementById("remove-style-btn");
    const highlightBtn = document.getElementById("highlight-btn");
    const removeHighlightBtn = document.getElementById("remove-highlight-btn");



    function createJsonFile(json) {
      return "data:text/json;charset=utf8," +
        encodeURIComponent(JSON.stringify(json));
    }

    // Set text content for details
    const updateTextContent = (elementId, count, totalCount) => {
      document.getElementById(elementId).textContent = count + "/" + totalCount;
    };

    //count building section
    function countBuilding(csvData) {
      const allBuildings = csvData.length;
      document.getElementById("all-building").textContent = allBuildings;

      const allDamageBuildingsText = document.getElementById("all-damage-building");
      const addressBld = getCategorizedFloodData(csvData);

      // Initialize counts for each category
      const counts = {
        "'床上（木造）'": 0,
        "'床下（木造）'": 0,
        "'床上（レンガ造）'": 0,
        "'床下（レンガ造）'": 0,
        "'床上（不明）'": 0,
        "'床下（不明）'": 0,
        "'浸水（非木造）'": 0,
        "'非浸水（木造）'": 0, //total 1
        "'非浸水（レンガ造）'": 0, //total 2
        "'非浸水（不明）'": 0, //total 3
        "'非浸水（非木造）'": 0 //total 4
      };

      // Calculate counts
      for (let i = 0; i < addressBld.length; i++) {
        const category = addressBld[i].category;
        if (counts.hasOwnProperty(category)) {
          counts[category] += addressBld[i].items.length;
        }
      }

      // console.log("counts", counts)

      const totalCount1 = counts["'床上（木造）'"] + counts["'床下（木造）'"] + counts["'非浸水（木造）'"];
      updateTextContent("detail-number-1", counts["'床上（木造）'"], totalCount1);
      updateTextContent("detail-number-2", counts["'床下（木造）'"], totalCount1);

      const totalCount2 = counts["'床上（レンガ造）'"] + counts["'床下（レンガ造）'"] + counts["'非浸水（レンガ造）'"];
      updateTextContent("detail-number-3", counts["'床上（レンガ造）'"], totalCount2);
      updateTextContent("detail-number-4", counts["'床下（レンガ造）'"], totalCount2);

      const totalCount3 = counts["'床上（不明）'"] + counts["'床下（不明）'"] + counts["'非浸水（不明）'"];
      updateTextContent("detail-number-5", counts["'床上（不明）'"], totalCount3);
      updateTextContent("detail-number-6", counts["'床下（不明）'"], totalCount3);

      const totalCount4 = counts["'浸水（非木造）'"] + counts["'非浸水（非木造）'"];
      updateTextContent("detail-number-9", counts["'浸水（非木造）'"], totalCount4);

      const totalDamageBuildingsCount = counts["'床上（木造）'"] + counts["'床下（木造）'"] + counts["'床上（レンガ造）'"] + counts["'床下（レンガ造）'"] + counts["'床上（不明）'"] + counts["'床下（不明）'"] + counts["'浸水（非木造）'"];
      allDamageBuildingsText.textContent = totalDamageBuildingsCount;

    }

    //getCategorizedFloodData function
    function getCategorizedFloodData(data) {
      // const filteredData = data.filter(obj => addresses.includes(obj["address'"]));
      const filteredData = data;


      const floodCategories = [
        "'非浸水'",
        "'床下（木造）'",
        "'床上（木造）'",
        "'床上（レンガ造）'",
        "'床下（レンガ造）'",
        "'床上（不明）'",
        "'床下（不明）'",
        "'浸水（非木造）'",
        "'非浸水（木造）'", //new1
        "'非浸水（レンガ造）'", //new2
        "'非浸水（不明）'", //new3
        "'非浸水（非木造）'", //new4
      ];

      const filteredFloodData = floodCategories.map(function (category) {
        const items = filteredData.filter(function (item) {
          return item["'flood_category'"] === category;
        });

        return {
          category: category,
          items: items
        };
      });
      return filteredFloodData
    }

    //getUniqueGidsByCategory
    function getUniqueGidsByCategory(data, fcategory) {
      // Filter data to find items that match the given flood category
      const filteredData = data.filter(item => item["'flood_category'"] === fcategory);

      // Extract and clean gid values in a single iteration
      const uniqueGids = filteredData.map(item => {
        const gidWithQuotes = item["'gid'"];
        return gidWithQuotes.replace(/'/g, "");
      });

      return uniqueGids;
    }

    //get all gids with addresses
    function getAllGidsWithAddresses(data, addresses) {
      const filteredData = data.filter(obj => addresses.includes(obj["address'"]) || addresses.includes(obj["'address'"]));

      const floodCategories = [
        "'非浸水'",
        "'床下（木造）'",
        "'床上（木造）'",
        "'床上（レンガ造）'",
        "'床下（レンガ造）'",
        "'床上（不明）'",
        "'床下（不明）'",
        "'浸水（非木造）'"
      ];

      const filteredFloodData = floodCategories.map(function (category) {
        const items = filteredData.filter(function (item) {
          return item["'flood_category'"] === category;
        });

        return {
          category: category,
          items: items
        };
      });

      return filteredFloodData
    }

    //get all by address
    function getAllDataByAddress(data, addresses) {
      const floodCategories = [
        "'非浸水'",
        "'床下（木造）'",
        "'床上（木造）'",
        "'床上（レンガ造）'",
        "'床下（レンガ造）'",
        "'床上（不明）'",
        "'床下（不明）'",
        "'浸水（非木造）'",
        "'非浸水（木造）'", //new1
        "'非浸水（レンガ造）'", //new2
        "'非浸水（不明）'", //new3
        "'非浸水（非木造）'", //new4
      ];

      const filteredData = addresses.map(address => {
        const items = data.filter(item => item["address'"] === address || item["'address'"] === address);

        let dividedItems = [];

        floodCategories.forEach(category => {
          const categoryItems = items.filter(item => item["'flood_category'"] === category);
          dividedItems.push({
            floodCategory: category,
            addressItems: categoryItems.length,
          });
        });

        return {
          住所: address,
          items: dividedItems
        }
      });


      return filteredData;
    }

    //address section
    function getUniqueAddressesWithFirstLocation(csvData) {
      const addressMap = new Map();

      // Loop through the data and fill up the map with the first occurrence of each address
      csvData.forEach(obj => {
        const address = obj["address'"] || obj["'address'"]; // Assuming the key for address in your object is "address'"
        if (!addressMap.has(address)) {
          // Only set the location if this is the first time we're encountering this address
          addressMap.set(address, {
            lat: obj["'lat'"], // Assuming the key for latitude in your object is "'lat'"
            lon: obj["'lon'"]  // Assuming the key for longitude in your object is "'lon'"
          });
        }
      });

      // Convert the map to an array of objects with 'address', 'lat', and 'lon' properties
      const uniqueAddressLocations = Array.from(addressMap, ([address, location]) => ({
        address: address,
        lat: location.lat,
        lon: location.lon
      }));

      // Sort the array of unique addresses by the address field
      uniqueAddressLocations.sort((a, b) => a.address.localeCompare(b.address));

      return uniqueAddressLocations;
    }



    function getSum(data, args) {
      let sum = 0;
      data.forEach(area => {
        area.items.forEach(item => {
          if (item.floodCategory === args) {
            sum += item.addressItems;
          }
        });
      });

      return sum
    }

    //handle color change
    function synchronizeColorInputs(inputId) {
      const colorInput = document.getElementById('color-value-' + inputId);
      const hexInput = document.getElementById('color-hex-' + inputId);

      // Add event listener to color input
      colorInput.addEventListener('input', function () {
        const selectedColor = colorInput.value;

        // Set the value of the hex input field
        hexInput.value = selectedColor;
      });

      // Add event listener to hex input
      hexInput.addEventListener('input', function () {
        const selectedHex = hexInput.value;

        // Set the value of the color input field
        colorInput.value = selectedHex;
      });

    }

    synchronizeColorInputs(1);
    synchronizeColorInputs(2);
    synchronizeColorInputs(3);
    synchronizeColorInputs(5);
    synchronizeColorInputs(6);
    synchronizeColorInputs(7);
    synchronizeColorInputs(9);


    //Handle style color and checkbox change
    function getStyleBuilding() {
      const colorHexes = [1, 2, 3, 5, 6, 7, 9].map(function (id) {
        return document.getElementById("color-hex-" + id).value;
      });

      const styles = [
        ["床上木造", checkbox31.checked, colorHexes[0]],
        ["床上レンガ造", checkbox32.checked, colorHexes[1]],
        ["床上不明", checkbox33.checked, colorHexes[2]],
        ["床下木造", checkbox35.checked, colorHexes[3]],
        ["床下レンガ造", checkbox36.checked, colorHexes[4]],
        ["床下不明", checkbox37.checked, colorHexes[5]],
        ["浸水非木造", checkbox39.checked, colorHexes[6]]
      ];

      return styles;
    }


    // build style file
    function buildStyleFile(styleArr, opacity) {
      const identifier = "gml_id";
      // Generate the conditions array dynamically based on bldg IDs
      const conditions = [].concat(...styleArr.map((item) => {
        const ids = item[0];
        const color = item[1];

        return ids.map(id => [
          "$" + "{" + identifier + "} === '" + id + "'",
          "color('" + color + "'," + opacity + ")"
        ]);
      }));

      const data = [...conditions,
      [
        "true",
        "color('white')"
      ]
      ]

      // Convert the data object to JSON string
      return data
    }

    //---end style color change

    let stateStatus = "initWidget"
    let csvUrl;
    let csvTitleToSend;
    let tile3dName;
    let csvData;
    window.addEventListener("message", e => {

      if (e.source !== parent) return;
      reearth = e.source.reearth;
      stateStatus = e.data.handle

      applyScalingFactors(e.source.reearth.viewport.height);

      switch (e.data.handle) {
        case "closePopup":
          //Close 凡例 popup
          document.querySelectorAll(".guide-image").forEach(obj => {
            obj.setAttribute("data-isOpen", false);
          })
          break;

        default:
          property = e.data.property;

          let geojsonName, geojsonUrl;

          const applyStyleBtn = document.getElementById("apply-style-btn");

          function removeSingleQuotes(str) {
            if (typeof str === 'string') {
              return str.replace(/^'+|'+$/g, '');
            }
            return str;
          }

          async function readCSV(url) {
            try {
              const data = await d3.csv(url);
              // Process the data: Clean the 'address' field in each row
              const cleanedData = data.map(row => {
                // Check for both 'address' and address' keys in the object
                const addressKeyWithQuote = row.hasOwnProperty("'address'") ? "'address'" :
                  row.hasOwnProperty("address'") ? "address'" : null;
                // If neither key is found, return the row as is
                if (!addressKeyWithQuote) return row;
                // Remove single quotes from the value of the address field
                const cleanedAddress = removeSingleQuotes(row[addressKeyWithQuote]);
                // Return a new row object with the cleaned address field
                return {
                  ...row,
                  [addressKeyWithQuote]: cleanedAddress
                };
              });
              return cleanedData;
            } catch (error) {
              console.error('Error:', error);
            }
          }

          function createCsvDropdown(csvArray) {
            const dropdownCSV = document.getElementById("dropdown-content-1");
            const titleCSV = document.getElementById("csv-name");
            dropdownCSV.innerHTML = "";

            if (csvArray.length <= 0) return;
            csvArray.forEach(data => {
              if (!data.csvUrl || !data.csvTitle) return;

              const csvSpan = document.createElement("span");
              csvSpan.textContent = data.csvTitle;
              csvSpan.classList.add("span-csv");
              csvSpan.addEventListener("click", () => {

                const allCsvSpans = document.querySelectorAll(".span-csv");
                allCsvSpans.forEach(item => item.classList.remove("active-address"));

                csvSpan.classList.add("active-address");
                titleCSV.textContent = data.csvTitle;
                //set csv url
                csvUrl = data.csvUrl;
                csvTitleToSend = data.csvTitle;

                dropdownCSV.classList.remove("show");
                processCsvAndCountBuildings();
              })

              if (!data.csvUrl && !data.csvTitle) return;

              dropdownCSV.appendChild(csvSpan);
            });

            // Set the last CSV as the default

            const lastCsvData = csvArray[csvArray.length - 1];
            if (lastCsvData && lastCsvData.csvUrl && lastCsvData.csvTitle) {
              const lastCsvSpan = dropdownCSV.lastChild;
              lastCsvSpan.classList.add("active-address");
              titleCSV.textContent = lastCsvData.csvTitle;
              // Assuming csvUrl and csvTitleToSend are defined in a higher scope
              csvUrl = lastCsvData.csvUrl;
              csvTitleToSend = lastCsvData.csvTitle;
              processCsvAndCountBuildings();
            }
          }

          if (property?.csvList) {
            //handle dropdown csv
            if (stateStatus === "initWidget") {
              createCsvDropdown(property.csvList);
            }
          }

          if (property?.settings?.townDataName) {
            geojsonName = property.settings.townDataName;
          }

          if (property?.settings?.townDataUrl) {
            geojsonUrl = property.settings.townDataUrl;
          }

          if (property?.settings?.tileDataName) {
            tile3dName = property.settings.tileDataName;
          }

          //get data
          async function processCsvAndCountBuildings() {
            csvData = await readCSV(csvUrl);
            initApply();

            const uniqueAddressesWithLocations = getUniqueAddressesWithFirstLocation(csvData);
            createAddressList(uniqueAddressesWithLocations);
            countBuilding(csvData);
          }

          async function createAddressList(addressArr) {
            const addressList = document.getElementById("dropdown-content-2");
            addressList.innerHTML = "";
            // const csvData = await readCSV(csvUrl);
            const checkAllSpan = document.createElement("span");
            checkAllSpan.id = "check-all-address";
            checkAllSpan.textContent = "すべて"

            //TODO: Refactor here
            checkAllSpan.addEventListener("click", () => {
              const addressBld = getCategorizedFloodData(csvData);

              checkAllSpan.classList.toggle("active-all-address");


              //if else: update button state (disabled, enabled) + updateCount(boolean) + setActiveClassForElements(boolean)

              if (checkAllSpan.classList.contains("active-all-address")) {
                // perform actions when class 'active' is added
                addressArr.forEach(function (addressElm) {
                  const addressItem = document.createElement("span");
                  addressItem.textContent = addressElm.address;
                  createAddressElement(addressElm);
                })
                checkAllSpan.classList.add("active-address");

                const addressDropdownItems = document.querySelectorAll(".address-dropdown-item");
                addressDropdownItems.forEach(item => {
                  item.classList.add("active-address");
                })


                //enable highlight button
                highlightBtn.classList.remove("disabled-btn");
                removeHighlightBtn.classList.remove("disabled-btn");


                let count1 = 0, count2 = 0, count3 = 0, count4 = 0, count5 = 0, count6 = 0, count9 = 0;
                let newCount1 = 0; // 木造 >> 非浸水(木造)
                let newCount2 = 0; // レンガ造  => 非浸水( レンガ造)
                let newCount3 = 0; // 不明 => 非浸水(不明)
                let newCount4 = 0; // 浸水(非木造) => 非浸水(非木造)

                for (let i = 0; i < addressBld.length; i++) {
                  if (addressBld[i].category === "'床上（木造）'") {
                    count1 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'床下（木造）'") {
                    count2 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'床上（レンガ造）'") {
                    count3 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'床下（レンガ造）'") {
                    count4 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'床上（不明）'") {
                    count5 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'床下（不明）'") {
                    count6 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'浸水（非木造）'") {
                    count9 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'非浸水（木造）'") {
                    newCount1 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'非浸水（レンガ造）'") {
                    newCount2 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'非浸水（不明）'") {
                    newCount3 = addressBld[i].items.length;
                  } else if (addressBld[i].category === "'非浸水（非木造）'") {
                    newCount4 = addressBld[i].items.length;
                  }
                }

                detailMachiNum1.textContent = count1 + "/" + (count1 + count2 + newCount1)
                detailMachiNum2.textContent = count2 + "/" + (count1 + count2 + newCount1)
                detailMachiNum3.textContent = count3 + "/" + (count3 + count4 + newCount2)
                detailMachiNum4.textContent = count4 + "/" + (count3 + count4 + newCount2)
                detailMachiNum5.textContent = count5 + "/" + (count5 + count6 + newCount3)
                detailMachiNum6.textContent = count6 + "/" + (count5 + count6 + newCount3)
                detailMachiNum9.textContent = count9 + "/" + (count9 + newCount4)


                allMachiDamageBuilding.textContent = count1 + count2 + count3 + count4 + count5 + count6 + count9

                allMachiBuilding.textContent = csvData.length

              } else {

                checkAllSpan.classList.remove("active-address");
                const addressDropdownItems = document.querySelectorAll(".address-dropdown-item");
                addressDropdownItems.forEach(item => {
                  item.classList.remove("active-address");
                })

                // perform actions when class 'active' is removed
                const pickedContentAddress = document.getElementById("picked-content-address");

                pickedContentAddress.innerHTML = "";

                //disabled highlight btn
                highlightBtn.classList.add("disabled-btn");
                removeHighlightBtn.classList.add("disabled-btn");

                //reset number
                detailMachiNum1.textContent = 0
                detailMachiNum2.textContent = 0
                detailMachiNum3.textContent = 0
                detailMachiNum4.textContent = 0
                detailMachiNum5.textContent = 0
                detailMachiNum6.textContent = 0
                detailMachiNum9.textContent = 0
                allMachiDamageBuilding.textContent = 0
                allMachiBuilding.textContent = 0


              }
            })


            addressList.appendChild(checkAllSpan);
            addressArr.forEach(function (addressElm) {
              const addressItem = document.createElement("span");
              addressItem.classList.add("address-dropdown-item");
              addressItem.textContent = addressElm.address;

              addressItem.addEventListener("click", () => {

                //enable highlight button
                highlightBtn.classList.remove("disabled-btn");
                removeHighlightBtn.classList.remove("disabled-btn");

                createAddressElement(addressElm);

                addressItem.classList.add("active-address");
                //store data to fly to area selected

                const pickerElms = document.querySelectorAll(".picked-elm");
                let pickedAddressesArr = [];
                pickerElms.forEach(picked => {
                  pickedAddressesArr.push(picked.textContent.trim());
                });

                const addressBld = getAllDataByAddress(csvData, pickedAddressesArr);

                //show the address tab data
                const machi0 = getSum(addressBld, "'非浸水'");
                const machi1 = getSum(addressBld, "'床上（木造）'");
                const machi2 = getSum(addressBld, "'床下（木造）'");
                const machi3 = getSum(addressBld, "'床上（レンガ造）'");
                const machi4 = getSum(addressBld, "'床下（レンガ造）'");
                const machi5 = getSum(addressBld, "'床上（不明）'");
                const machi6 = getSum(addressBld, "'床下（不明）'");

                const machi9 = getSum(addressBld, "'浸水（非木造）'");

                const newMachi1 = getSum(addressBld, "'非浸水（木造）'");
                const newMachi2 = getSum(addressBld, "'非浸水（レンガ造）'");
                const newMachi3 = getSum(addressBld, "'非浸水（不明）'");
                const newMachi4 = getSum(addressBld, "'非浸水（非木造）'");



                detailMachiNum1.textContent = machi1 + "/" + (machi1 + machi2 + newMachi1)
                detailMachiNum2.textContent = machi2 + "/" + (machi1 + machi2 + newMachi1)
                detailMachiNum3.textContent = machi3 + "/" + (machi3 + machi4 + newMachi2)
                detailMachiNum4.textContent = machi4 + "/" + (machi4 + machi4 + newMachi2)
                detailMachiNum5.textContent = machi5 + "/" + (machi5 + machi6 + newMachi3)
                detailMachiNum6.textContent = machi6 + "/" + (machi5 + machi6 + newMachi3)

                detailMachiNum9.textContent = machi9 + "/" + (machi9 + newMachi4)


                allMachiDamageBuilding.textContent = machi1 + machi2 + machi3 + machi4 + machi5 + machi6 + machi9
                allMachiBuilding.textContent = machi0 + machi1 + machi2 + machi3 + machi4 + machi5 + machi6 + machi9 + newMachi1 + newMachi2 + newMachi3 + newMachi4

              })

              addressList.appendChild(addressItem);
            });
          }


          async function createAddressElement(addressElm) {

            //check if all address is checked
            // const isAllAddressChecked = document.getElementById("check-all-address").classList.contains("active-address");

            // Create main div element with class 'picked-elm'
            const divPickedElm = document.createElement('div');
            divPickedElm.className = 'picked-elm';

            // Create title div with class 'picked-elm-title' and text content
            const divTitle = document.createElement('div');
            divTitle.className = 'picked-elm-title';
            divTitle.textContent = addressElm.address;

            // Append title div to main div
            divPickedElm.appendChild(divTitle);

            // Create button group div with class 'picked-elm-button-group'
            const divBtnGroup = document.createElement('div');
            divBtnGroup.className = 'picked-elm-button-group';

            const divHighlightBtn = document.createElement('div');
            divHighlightBtn.className = 'picked-btn';
            divHighlightBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">' +
              '<path d="M5.5 14.5H10.5" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"/>' +
              '<path d="M4.91898 10.4382C4.32445 9.97389 3.8429 9.38082 3.51054 8.70359C3.17818 8.02637 3.00365 7.28262 3.00008 6.52825C2.9851 3.8181 5.17 1.56522 7.87944 1.50145C8.92935 1.47617 9.96058 1.78212 10.8268 2.37589C11.6931 2.96967 12.3504 3.82113 12.7055 4.80949C13.0606 5.79786 13.0955 6.87294 12.8052 7.88225C12.5149 8.89156 11.9142 9.78384 11.0883 10.4325C10.9064 10.5735 10.7589 10.7539 10.657 10.9603C10.555 11.1666 10.5014 11.3934 10.5 11.6235L10.5 12C10.5 12.1326 10.4473 12.2598 10.3536 12.3536C10.2598 12.4474 10.1326 12.5 10 12.5H5.99999C5.86738 12.5 5.74021 12.4474 5.64644 12.3536C5.55267 12.2598 5.49999 12.1326 5.49999 12L5.49998 11.6231C5.49942 11.3945 5.44681 11.1689 5.34614 10.9637C5.24548 10.7584 5.0994 10.5787 4.91898 10.4382V10.4382Z" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"/>' +
              '<path d="M8.50781 3.54907C9.11938 3.65303 9.68359 3.94431 10.1225 4.38268C10.5614 4.82106 10.8534 5.38491 10.9581 5.99635" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"/>' +
              '</svg>';
            divHighlightBtn.addEventListener("click", () => {


              if (!divHighlightBtn.classList.contains("active-highlight")) {
                divHighlightBtn.classList.add("active-highlight");

                let highlightAddressArray = [];
                const divPickedGroupElements = document.querySelectorAll('.picked-elm .picked-elm-button-group');
                divPickedGroupElements.forEach(elm => {
                  if (elm.firstChild.classList.contains('active-highlight')) {
                    const divGr = elm.closest(".picked-elm");

                    if (!divGr) return;
                    highlightAddressArray.push(divGr.querySelector(".picked-elm-title").textContent);
                  }
                })

                const stylesHighlightCondition = createConditionsFromAddresses(highlightAddressArray);
                const geojsonAddedLayer = reearth.layers.find(layer => layer.title === geojsonName);


                if (!geojsonAddedLayer) {
                  reearth.layers.add({
                    // always same
                    type: "simple",
                    title: geojsonName,
                    // 1. how to load data
                    data: {
                      type: "geojson",
                      url: geojsonUrl
                    },
                    polygon: {
                      classificationType: "terrain",
                      fillColor: {
                        expression: {
                          conditions: stylesHighlightCondition,
                        },
                      },
                      clampToGround: true,
                      heightReference: "clamp",
                      stroke: true,
                      strokeColor: "#00ff0064",
                    },
                  });
                } else {
                  reearth.layers.override(geojsonAddedLayer.id, {
                    polygon: {
                      classificationType: "terrain",
                      fillColor: {
                        expression: {
                          conditions: stylesHighlightCondition,
                        },
                      },
                      clampToGround: true,
                      heightReference: "clamp",
                      stroke: true,
                      strokeColor: "#00ff0064",
                    },
                  });
                }


                // handle active style, add color to geojson
              } else {
                divHighlightBtn.classList.remove("active-highlight");

                // remove style of this region
                let highlightAddressArray = [];

                const divPickedGroupElements = document.querySelectorAll('.picked-elm .picked-elm-button-group');
                divPickedGroupElements.forEach(elm => {
                  if (elm.firstChild.classList.contains('active-highlight')) {
                    const divGr = elm.closest(".picked-elm");
                    if (!divGr) return;
                    highlightAddressArray.push(divGr.querySelector(".picked-elm-title").textContent);
                  }
                })
                const stylesHighlightCondition = createConditionsFromAddresses(highlightAddressArray);

                const geojsonAddedLayer = reearth.layers.find(layer => layer.title === geojsonName);


                if (!geojsonAddedLayer) {
                  reearth.layers.add({
                    // always same
                    type: "simple",
                    title: geojsonName,
                    // 1. how to load data
                    data: {
                      type: "geojson",
                      url: geojsonUrl
                    },
                    polygon: {
                      classificationType: "terrain",
                      fillColor: {
                        expression: {
                          conditions: stylesHighlightCondition,
                        },
                      },
                      clampToGround: true,
                      heightReference: "clamp",
                      stroke: true,
                      strokeColor: "#00ff0064",
                    },
                  });
                } else {
                  reearth.layers.override(geojsonAddedLayer.id, {
                    polygon: {
                      classificationType: "terrain",
                      fillColor: {
                        expression: {
                          conditions: stylesHighlightCondition,
                        },
                      },
                      clampToGround: true,
                      heightReference: "clamp",
                      stroke: true,
                      strokeColor: "#00ff0064",
                    },
                  });
                }

              }

            })


            // Create move camera button with SVG icon
            const divMoveCameraBtn = document.createElement('div');
            divMoveCameraBtn.className = 'picked-btn';

            divMoveCameraBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M10.5 3H13V5.5" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M5.5 13H3V10.5" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M13 10.5V13H10.5" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M3 5.5V3H5.5" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M5.25 8H10.75" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M8 5.25V10.75" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"></path> </svg>';

            divMoveCameraBtn.addEventListener('click', () => {
              reearth.camera.flyTo({
                lat: parseFloat(addressElm.lat),
                lng: parseFloat(addressElm.lon),
                height: 3000,
                heading: 0,
                pitch: -1.5,
                roll: 0
              }, {
                duration: 2   // seconds
              });


              //add active element for camera chosen
              const allPickedElements = document.querySelectorAll(".picked-elm");
              allPickedElements.forEach((elm) => {
                elm.classList.remove("active-camera");
              })

              divPickedElm.classList.add("active-camera");

            });

            // Create remove button with SVG icon
            const divRemoveBtn = document.createElement('div');
            divRemoveBtn.className = 'picked-btn';
            divRemoveBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.5 3.5L3.5 12.5" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12.5 12.5L3.5 3.5" stroke="black" stroke-opacity="0.45" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
            divRemoveBtn.addEventListener("click", async () => {
              // const csvData = await readCSV(csvUrl);

              const dropdownContent2 = document.getElementById("dropdown-content-2");
              const spans = dropdownContent2.getElementsByTagName('span');

              for (let i = 0; i < spans.length; i++) {
                if (spans[i].textContent === divTitle.textContent) {
                  spans[i].classList.remove("active-address"); // Remove the matching span element
                  break;
                }
              }
              divPickedElm.remove();

              //check if any picked-elm exist
              const pickerElms = document.querySelectorAll(".picked-elm");
              let pickedAddressesArr = [];
              pickerElms.forEach(picked => {
                pickedAddressesArr.push(picked.textContent.trim());
              });

              const addressBld = getAllDataByAddress(csvData, pickedAddressesArr);

              //show the address tab data
              const machi0 = getSum(addressBld, "'非浸水'");
              const machi1 = getSum(addressBld, "'床上（木造）'");
              const machi2 = getSum(addressBld, "'床下（木造）'");
              const machi3 = getSum(addressBld, "'床上（レンガ造）'");
              const machi4 = getSum(addressBld, "'床下（レンガ造）'");
              const machi5 = getSum(addressBld, "'床上（不明）'");
              const machi6 = getSum(addressBld, "'床下（不明）'");

              const machi9 = getSum(addressBld, "'浸水（非木造）'");

              const newMachi1 = getSum(addressBld, "'非浸水（木造）'");
              const newMachi2 = getSum(addressBld, "'非浸水（レンガ造）'");
              const newMachi3 = getSum(addressBld, "'非浸水（不明）'");
              const newMachi4 = getSum(addressBld, "'非浸水（非木造）'");


              detailMachiNum1.textContent = machi1 + "/" + (machi1 + machi2 + newMachi1)
              detailMachiNum2.textContent = machi2 + "/" + (machi1 + machi2 + newMachi1)
              detailMachiNum3.textContent = machi3 + "/" + (machi3 + machi4 + newMachi2)
              detailMachiNum4.textContent = machi4 + "/" + (machi3 + machi4 + newMachi2)
              detailMachiNum5.textContent = machi5 + "/" + (machi5 + machi6 + newMachi3)
              detailMachiNum6.textContent = machi6 + "/" + (machi5 + machi6 + newMachi3)

              detailMachiNum9.textContent = machi9 + "/" + (machi9 + newMachi4)


              allMachiDamageBuilding.textContent = machi1 + machi2 + machi3 + machi4 + machi5 + machi6 + machi9
              allMachiBuilding.textContent = machi0 + machi1 + machi2 + machi3 + machi4 + machi5 + machi6 + machi9 + newMachi1 + newMachi2 + newMachi3 + newMachi4



              if (pickerElms.length === 0) {
                //hide address tab data
                highlightBtn.classList.add("disabled-btn");
                removeHighlightBtn.classList.add("disabled-btn");
              } else {
                //show address tab data
                highlightBtn.classList.remove("disabled-btn");
                removeHighlightBtn.classList.remove("disabled-btn");
              }

              //auto override highlight when clicked
              let highlightAddressArray = [];

              const divPickedGroupElements = document.querySelectorAll('.picked-elm .picked-elm-button-group');
              divPickedGroupElements.forEach(elm => {
                if (elm.firstChild.classList.contains('active-highlight')) {
                  const divGr = elm.closest(".picked-elm");
                  if (!divGr) return;
                  highlightAddressArray.push(divGr.querySelector(".picked-elm-title").textContent);
                }
              })
              const stylesHighlightCondition = createConditionsFromAddresses(highlightAddressArray);

              const geojsonAddedLayer = reearth.layers.find(layer => layer.title === geojsonName);


              if (!geojsonAddedLayer) {
                reearth.layers.add({
                  // always same
                  type: "simple",
                  title: geojsonName,
                  // 1. how to load data
                  data: {
                    type: "geojson",
                    url: geojsonUrl
                  },
                  polygon: {
                    classificationType: "terrain",
                    fillColor: {
                      expression: {
                        conditions: stylesHighlightCondition,
                      },
                    },
                    clampToGround: true,
                    heightReference: "clamp",
                    stroke: true,
                    strokeColor: "#00ff0064",
                  },
                });
              } else {
                reearth.layers.override(geojsonAddedLayer.id, {
                  polygon: {
                    classificationType: "terrain",
                    fillColor: {
                      expression: {
                        conditions: stylesHighlightCondition,
                      },
                    },
                    clampToGround: true,
                    heightReference: "clamp",
                    stroke: true,
                    strokeColor: "#00ff0064",
                  },
                });
              }

            });


            // Append buttons to button group div
            divBtnGroup.appendChild(divHighlightBtn);
            divBtnGroup.appendChild(divMoveCameraBtn);
            divBtnGroup.appendChild(divRemoveBtn);

            // Append button group to main div
            divPickedElm.appendChild(divBtnGroup);

            // // Return the complete element
            // return divPickedElm;

            const pickedContentAddress = document.getElementById("picked-content-address");
            //check if already picked
            const divPickedElmTitle = divPickedElm.querySelector('.picked-elm-title').textContent;
            // Check if there's already an element with the same title
            const existingTitles = pickedContentAddress.getElementsByClassName('picked-elm-title');
            let isExisting = false;
            for (let i = 0; i < existingTitles.length; i++) {
              if (existingTitles[i].textContent === divPickedElmTitle) {
                isExisting = true;
                break; // Break out of the loop if a match is found
              }
            }
            if (!isExisting) {
              // If no existing title matches, append the new element
              pickedContentAddress.appendChild(divPickedElm);
            }
          }

          //preload geojson data
          const geojsonPreloadAddedLayer = reearth.layers.find(layer => layer.title === geojsonName);
          if (!geojsonPreloadAddedLayer) {
            reearth.layers.add({
              // always same
              type: "simple",
              title: geojsonName,
              // 1. how to load data
              data: {
                type: "geojson",
                url: geojsonUrl
              },
              polygon: {
                classificationType: "terrain",
                fillColor: {
                  expression: {
                    conditions: [["true", "color('transparent')"]]
                  },
                },
                clampToGround: true,
                heightReference: "clamp",
                stroke: true,
                strokeColor: "transparent",
              },
            });
          }

          function createConditionsFromAddresses(addresses) {
            let conditionsArray = addresses.map(address => [
              "$" + "{S_NAME}==='" + address + "'",
              "color('#00ff0064')"
            ]);

            // Append the default condition with the defaultColor at the end
            conditionsArray.push(["true", "color('transparent')"]);

            return conditionsArray;
          }

          //highlight function
          async function highlightLayer() {
            //abc
            // const data = await readCSV(csvUrl);
            //get all picked address
            const allPickedAddresses = document.querySelectorAll(".picked-elm");
            let pickedAddressesArr = [];
            allPickedAddresses.forEach(picked => {
              pickedAddressesArr.push(picked.textContent.trim());

              picked.querySelector(".picked-elm-button-group").firstChild.classList.add("active-highlight");
            });


            const stylesCondition = createConditionsFromAddresses(pickedAddressesArr);
            const geojsonAddedLayer = reearth.layers.find(layer => layer.title === geojsonName);

            if (pickedAddressesArr.length === 0) {
              if (!geojsonAddedLayer) return;

              reearth.layers.override(geojsonAddedLayer.id, {
                polygon: {
                  fillColor: "transparent",
                  clampToGround: true,
                  heightReference: "clamp",
                  stroke: true,
                  strokeColor: "#00ff0064",
                }
              });
            } else {
              if (!geojsonAddedLayer) {
                reearth.layers.add({
                  // always same
                  type: "simple",
                  title: geojsonName,
                  // 1. how to load data
                  data: {
                    type: "geojson",
                    url: geojsonUrl
                  },
                  polygon: {
                    classificationType: "terrain",
                    fillColor: {
                      expression: {
                        conditions: stylesCondition,
                      },
                    },
                    clampToGround: true,
                    heightReference: "clamp",
                    stroke: true,
                    strokeColor: "#00ff0064",
                  },
                });
              } else {
                reearth.layers.override(geojsonAddedLayer.id, {
                  polygon: {
                    classificationType: "terrain",
                    fillColor: {
                      expression: {
                        conditions: stylesCondition,
                      },
                    },
                    clampToGround: true,
                    heightReference: "clamp",
                    stroke: true,
                    strokeColor: "#00ff0064",
                  },
                });
              }

            }
          }


          highlightBtn.addEventListener("click", highlightLayer);


          //remove highlight
          function removeHighlightLayer() {
            const geojsonAddedLayer = reearth.layers.find(layer => layer.title === geojsonName)

            if (!geojsonAddedLayer) return;
            reearth.layers.override(geojsonAddedLayer.id, {
              polygon: {
                fillColor: "transparent",
                clampToGround: true,
                heightReference: "clamp",
                stroke: true,
                strokeColor: "transparent",
              }
            });

            //remove active-highlight class
            const allActiveHighlightElms = document.querySelectorAll(".active-highlight");
            allActiveHighlightElms.forEach(elm => elm.classList.remove("active-highlight"));

          }
          removeHighlightBtn.addEventListener("click", removeHighlightLayer);

          //handle download button
          document.getElementById("download-btn").addEventListener("click", async (e) => {
            e.preventDefault();

            // get json style file

            const styleData = getStyleBuilding();

            const addressMap = {
              '床上木造': '床上（木造）',
              '床上レンガ造': '床上（レンガ造）',
              '床上不明': '床上（不明）',
              '浸水非木造': '浸水（非木造）',
              '床下木造': '床下（木造）',
              '床下レンガ造': '床下（レンガ造）',
              '床下不明': '床下（不明）',
            };

            const filteredData = styleData
              .filter((item) => item[1]) // Keep only items with checkbox === true
              .map((item) => ({
                checkbox: item[1],
                text: addressMap[item[0]],
                colorHex: item[2]
              }));

            //abc
            let pickedAddressesArr = [];
            const uniqueAddressesWithLocations = getUniqueAddressesWithFirstLocation(csvData);

            uniqueAddressesWithLocations.forEach(unique => {
              pickedAddressesArr.push(unique.address.trim());
            })

            // const csvData = await readCSV(csvUrl);

            const addressBld = getAllGidsWithAddresses(csvData, pickedAddressesArr);


            let styleArr = [];

            const newData = addressBld.reduce(function (result, obj) {
              return result.concat(obj.items);
            }, []);

            for (let i = 0; i < filteredData.length; i++) {
              const gidArr = getUniqueGidsByCategory(newData, "'" + filteredData[i].text + "'");
              styleArr.push([gidArr, filteredData[i].colorHex, filteredData[i].text]);
            }

            // opacity
            const opacitySlider = document.getElementById("opacity-slider");
            let opacity = opacitySlider.value / 10;

            // Handle the change event on the slider to get the new value
            opacitySlider.addEventListener('input', () => {
              opacity = opacitySlider.value / 10;
            });
            // //create style json file

            const jsonDataStyle = buildStyleFile(styleArr, opacity);

            //get csv file
            const addressBldForCsv = getAllDataByAddress(csvData, pickedAddressesArr);

            const transformedData = addressBldForCsv.map(item => {
              const newItem = {
                '住所': item['住所'],
                '床上(木造)': 0,
                '床上(レンガ造)': 0,
                '床上(不明)': 0,
                '床下(木造)': 0,
                '床下(レンガ造)': 0,
                '床下(不明)': 0,
                '浸水(非木造)': 0,
                '総建物数': 0
              };

              item.items.forEach(category => {
                switch (category.floodCategory) {
                  case "'床上（木造）'":
                    newItem['床上(木造)'] = category.addressItems;
                    break;
                  case "'床上（レンガ造）'":
                    newItem['床上(レンガ造)'] = category.addressItems;
                    break;
                  case "'床上（不明）'":
                    newItem['床上(不明)'] = category.addressItems;
                    break;
                  case "'床下（木造）'":
                    newItem['床下(木造)'] = category.addressItems;
                    break;
                  case "'床下（レンガ造）'":
                    newItem['床下(レンガ造)'] = category.addressItems;
                    break;
                  case "'床下（不明）'":
                    newItem['床下(不明)'] = category.addressItems;
                    break;
                  case "'浸水（非木造）'":
                    newItem['浸水(非木造)'] = category.addressItems;
                    break;
                  case "'非浸水'":
                    newItem['総建物数'] = category.addressItems;
                    break;
                  // New cases:
                  case "'非浸水（木造）'":
                    newItem['総建物数'] += category.addressItems;
                    break;
                  case "'非浸水（レンガ造）'":
                    newItem['総建物数'] += category.addressItems;
                    break;
                  case "'非浸水（不明）'":
                    newItem['総建物数'] += category.addressItems;
                    break;
                  case "'非浸水（非木造）'":
                    newItem['総建物数'] += category.addressItems;
                    break;
                }
              });

              return newItem;
            });

            parent.postMessage({ type: "showModal", styleData: jsonDataStyle, csvSendData: transformedData }, "*");

          });


          async function initApply(init = false) {
            sendDataToLayerManagementPlugin();
            sendDataInitialization();

            //then get csv data
            let pickedAddressesArrForPreApplyBuilding = [];


            if (init) {
              csvData = await readCSV(csvUrl);
            }

            const uniqueAddressesWithLocationsForPreApplyBuilding = getUniqueAddressesWithFirstLocation(csvData);

            uniqueAddressesWithLocationsForPreApplyBuilding.forEach(unique => {
              pickedAddressesArrForPreApplyBuilding.push(unique.address.trim());
            })

            //then build style  >>  need styleArr and opacity=1
            // checkbox default all with color default

            const styleForPreApplyBuilding = [
              [
                "床上木造",
                true,
                "#0000FF"
              ],
              [
                "床上レンガ造",
                true,
                "#FA0000"
              ],
              [
                "床上不明",
                true,
                "#FFFF00"
              ],
              [
                "床下木造",
                true,
                "#00FFFF"
              ],
              [
                "床下レンガ造",
                true,
                "#FFB8E5"
              ],
              [
                "床下不明",
                true,
                "#8B4513"
              ],
              [
                "浸水非木造",
                true,
                "#9370DB"
              ]
            ]

            const opacityForPreApplyBuilding = 1;

            const addressBld = getAllGidsWithAddresses(csvData, pickedAddressesArrForPreApplyBuilding);

            const addressMap = {
              '床上木造': '床上（木造）',
              '床上レンガ造': '床上（レンガ造）',
              '床上不明': '床上（不明）',
              '床下木造': '床下（木造）',
              '床下レンガ造': '床下（レンガ造）',
              '床下不明': '床下（不明）',
              '浸水非木造': '浸水（非木造）'
            };

            const filteredData = styleForPreApplyBuilding
              .filter((item) => item[1]) // Keep only items with checkbox === true
              .map((item) => ({
                checkbox: item[1],
                text: addressMap[item[0]],
                colorHex: item[2]
              }));

            let styleArrForPreApplyBuilding = [];

            const newData = addressBld.reduce(function (result, obj) {
              return result.concat(obj.items);
            }, []);

            for (let i = 0; i < filteredData.length; i++) {
              const gidArr = getUniqueGidsByCategory(newData, "'" + filteredData[i].text + "'");
              styleArrForPreApplyBuilding.push([gidArr, filteredData[i].colorHex, filteredData[i].text]);
            }

            const jsonDataStyleForPreApplyBuilding = buildStyleFile(styleArrForPreApplyBuilding, opacityForPreApplyBuilding);

            const geojsonAddedLayer = reearth.layers.find(layer => layer.title === tile3dName);

            if (!geojsonAddedLayer) {
              reearth.layers.add({
                type: "simple",
                data: {
                  type: "3dtiles",

                  url: "https://assets.cms.plateau.reearth.io/assets/2d/b493a3-0bdb-4e5a-8acc-83d0c69709f9/omutabldg/tileset.json",
                },
                title: tile3dName,
                "3dtiles": {
                  color: {
                    "expression": {
                      "conditions": jsonDataStyleForPreApplyBuilding,
                    }
                  }
                }
              });
            } else {
              reearth.layers.override(geojsonAddedLayer.id, {
                "3dtiles": {
                  color: {
                    "expression": {
                      "conditions": jsonDataStyleForPreApplyBuilding,
                    }
                  }
                }
              });
            }

          }

          if (stateStatus == "initWidget") {
            initApply(true);
          }

          function sendDataToLayerManagementPlugin() {
            parent.postMessage({ type: "sendDataToLayerManagementPlugin", message: { csvTitleToSend, csvUrl } }, "*")
          }

          function sendDataInitialization() {
            parent.postMessage({ type: "sendDataInitially", message: { csvTitleToSend, csvUrl } }, "*");
          }
          sendDataInitialization();

          //handle apply style
          applyStyleBtn.addEventListener('click', async () => {
            let checkboxStates = [];

            // Loop over checkboxes in group 1 and check their status
            checkboxesGroup1.forEach((checkbox) => {
              if (checkbox.checked) {
                // Apply the style if checkbox is checked
                // Replace the code below with whatever style you want to apply
                checkboxStates.push(checkbox.id);
              }
            });

            // Loop over checkboxes in group 2 and check their status
            checkboxesGroup2.forEach((checkbox) => {
              if (checkbox.checked) {
                // Apply the style if checkbox is checked
                // Replace the code below with whatever style you want to apply
                checkboxStates.push(checkbox.id);
              }
            });

            // Loop over checkboxes in group 3 and check their status
            checkboxesGroup3.forEach((checkbox) => {
              if (checkbox.checked) {
                // Apply the style if checkbox is checked
                // Replace the code below with whatever style you want to apply
                checkboxStates.push(checkbox.id);
              }
            });

            // opacity
            const opacitySlider = document.getElementById("opacity-slider");
            let opacity = opacitySlider.value / 10;

            // Handle the change event on the slider to get the new value
            opacitySlider.addEventListener('input', () => {
              opacity = opacitySlider.value / 10;
            });

            const styleData = getStyleBuilding();

            const addressMap = {
              '床上木造': '床上（木造）',
              '床上レンガ造': '床上（レンガ造）',
              '床上不明': '床上（不明）',
              '床下木造': '床下（木造）',
              '床下レンガ造': '床下（レンガ造）',
              '床下不明': '床下（不明）',
              '浸水非木造': '浸水（非木造）'
            };

            const filteredData = styleData
              .filter((item) => item[1]) // Keep only items with checkbox === true
              .map((item) => ({
                checkbox: item[1],
                text: addressMap[item[0]],
                colorHex: item[2]
              }));


            let pickedAddressesArr = [];

            // const csvData = await readCSV(csvUrl);
            const uniqueAddressesWithLocations = getUniqueAddressesWithFirstLocation(csvData);

            uniqueAddressesWithLocations.forEach(unique => {
              pickedAddressesArr.push(unique.address.trim());
            })

            const addressBld = getAllGidsWithAddresses(csvData, pickedAddressesArr);


            let styleArr = [];

            const newData = addressBld.reduce(function (result, obj) {
              return result.concat(obj.items);
            }, []);

            for (let i = 0; i < filteredData.length; i++) {
              const gidArr = getUniqueGidsByCategory(newData, "'" + filteredData[i].text + "'");
              styleArr.push([gidArr, filteredData[i].colorHex, filteredData[i].text]);
            }

            // //create style json file
            const jsonDataStyle = buildStyleFile(styleArr, opacity);

            const geojsonAddedLayerInside = reearth.layers.find(layer => layer.title === tile3dName);

            if (geojsonAddedLayerInside) reearth.layers.delete(geojsonAddedLayerInside.id);

            if (!geojsonAddedLayerInside) {
              reearth.layers.add({
                type: "simple",
                data: {
                  type: "3dtiles",

                  url: "https://assets.cms.plateau.reearth.io/assets/2d/b493a3-0bdb-4e5a-8acc-83d0c69709f9/omutabldg/tileset.json",
                },
                title: tile3dName,
                "3dtiles": {
                  color: {
                    "expression": {
                      "conditions": jsonDataStyle,
                    }
                  }
                }
              });
            } else {
              reearth.layers.override(geojsonAddedLayerInside.id, {
                "3dtiles": {
                  color: {
                    "expression": {
                      "conditions": jsonDataStyle,
                    }
                  }
                }
              })

            }

            // ----------------------------------------------------------------
            // change dot color in count building section
            document.getElementById("detail-color-1").style.background = document.getElementById("color-hex-1").value;
            document.getElementById("detail-color-2").style.background = document.getElementById("color-hex-5").value;
            document.getElementById("detail-color-3").style.background = document.getElementById("color-hex-2").value;
            document.getElementById("detail-color-4").style.background = document.getElementById("color-hex-6").value;
            document.getElementById("detail-color-5").style.background = document.getElementById("color-hex-3").value;
            document.getElementById("detail-color-6").style.background = document.getElementById("color-hex-7").value;
            document.getElementById("detail-color-9").style.background = document.getElementById("color-hex-9").value;

            //change in detail machi count building
            document.getElementById("detail-machi-color-1").style.background = document.getElementById("color-hex-1").value;
            document.getElementById("detail-machi-color-2").style.background = document.getElementById("color-hex-5").value;
            document.getElementById("detail-machi-color-3").style.background = document.getElementById("color-hex-2").value;
            document.getElementById("detail-machi-color-4").style.background = document.getElementById("color-hex-6").value;
            document.getElementById("detail-machi-color-5").style.background = document.getElementById("color-hex-3").value;
            document.getElementById("detail-machi-color-6").style.background = document.getElementById("color-hex-7").value;

            document.getElementById("detail-machi-color-9").style.background = document.getElementById("color-hex-9").value;

            //----------------------------------------------------------------

            // ----------------------------------------------------------------
            // send the message to the server
            const message = {
              message: "settings",
              url: csvUrl,
              satellite: "",
              datetime: "",
              title: csvTitleToSend,
              colors: {
                床上: {
                  木造: document.getElementById("color-hex-1").value,
                  レンガ造: document.getElementById("color-hex-2").value,
                  不明: document.getElementById("color-hex-3").value,
                },
                床下: {
                  木造: document.getElementById("color-hex-5").value,
                  レンガ造: document.getElementById("color-hex-6").value,
                  不明: document.getElementById("color-hex-7").value,
                },
                浸水: {
                  非木造: document.getElementById("color-hex-9").value
                }
              },
            };

            //send message
            parent.postMessage({ type: "sendMessage", message: message }, "*");
            // -------

          });
          //end apply style button

          //handle remove style
          removeStyleBtn.addEventListener('click', () => {
            // reset the color to default
            //#0000FF, #FA0000, #FFFF00, #00FFFF, #FFB8E5, #8B4513, #9370DB
            document.getElementById("color-value-1").value = "#0000FF";
            document.getElementById("color-hex-1").value = "#0000FF";
            document.getElementById("color-value-2").value = "#FA0000";
            document.getElementById("color-hex-2").value = "#FA0000";
            document.getElementById("color-value-3").value = "#FFFF00";
            document.getElementById("color-hex-3").value = "#FFFF00";

            document.getElementById("color-value-5").value = "#00FFFF";
            document.getElementById("color-hex-5").value = "#00FFFF";
            document.getElementById("color-value-6").value = "#FFB8E5";
            document.getElementById("color-hex-6").value = "#FFB8E5";
            document.getElementById("color-value-7").value = "#8B4513";
            document.getElementById("color-hex-7").value = "#8B4513";

            document.getElementById("color-value-9").value = "#9370DB";
            document.getElementById("color-hex-9").value = "#9370DB";


            [checkboxAll, checkbox3all1, checkbox3all2, checkbox3all3].forEach(checkbox => {
              if (checkbox.checked) {
                checkbox.checked = false;
              }
            })
            checkboxesGroup1.forEach(checkbox => {
              if (checkbox.checked) {
                checkbox.checked = false;
              }
            })

            checkboxesGroup2.forEach(checkbox => {
              if (checkbox.checked) {
                checkbox.checked = false;
              }
            })

            checkboxesGroup3.forEach(checkbox => {
              if (checkbox.checked) {
                checkbox.checked = false;
              }
            })

            // const defaultCondition = [
            //   "true",
            //   "color('white')"
            // ]
            let layerIds = [];

            let allLayers = reearth.layers.layers;
            for (let i = 0; i < allLayers.length; i++) {
              if (allLayers[i].children === undefined) {
                if (allLayers[i].type == "simple" && allLayers[i].title == "3D Tile Layer" && allLayers[i]["3dtiles"] !== undefined) {
                  layerIds.push(allLayers[i]);
                }

              } else {
                if (allLayers[i].type == "group") {
                  let children = allLayers[i].children
                  for (let j = 0; j < children.length; j++) {
                    if (children[j].data.type == "3dtiles" && children[j].data.url !== undefined && children[j].title == "3D Tile Layer") {
                      layerIds.push(children[j])
                    }
                  }
                }
              }
            }

            const defaultCondition = [
              [
                "true",
                "color('white')"
              ]
            ]

            layerIds.forEach((layer) => {

              reearth.layers.override(layer.id, {
                "3dtiles": {
                  color: {
                    "expression": {
                      "conditions": defaultCondition,
                    }
                  }
                }
              });
            })
          });



          break;
      }

      // Apply scaling factors based on viewport height
      function applyScalingFactors(viewportHeight) {
        const mainDisplay = document.getElementById("main");
        const scalingFactors = [
          { breakpoint: 100, factor: 0.32 },
          { breakpoint: 200, factor: 0.40 },
          { breakpoint: 300, factor: 0.50 },
          { breakpoint: 350, factor: 0.60 },
          { breakpoint: 400, factor: 0.62 },
          { breakpoint: 450, factor: 0.68 },
          { breakpoint: 500, factor: 0.72 },
          { breakpoint: 600, factor: 0.79 },
          { breakpoint: 700, factor: 0.834 },
          { breakpoint: Infinity, factor: 0.854 }
        ];

        let scaleFactor = scalingFactors.find(f => viewportHeight <= f.breakpoint).factor;
        mainDisplay.style.maxHeight = viewportHeight * scaleFactor + "px";
      }

    });

  </script>
  `,
  { width: 180, height: 46 }
  );

  const modal = `
  <style>
    html,
    body {
      margin: 0;
      width: 572px;
      height: 396px;
    }

    #wrapper {
      box-sizing: border-box;
      background: #fff;
      box-shadow: 0px -1px 0px 0px #F0F0F0 inset;

      border: 1px solid #D9D9D9;
      height: 100%;
      overflow-x: hidden;
      overflow-y: hidden;
    }

    .modal-header {
      display: flex;
      padding: var(--icon-normal, 16px) 24px;

      justify-content: space-between;
      align-items: center;
      align-self: stretch;

      background: var(--neutral-1, #FFF);

      /* border & divider/divider ↓ */
      box-shadow: 0px -1px 0px 0px #F0F0F0 inset;
    }

    .modal-title {
      color: var(--character-title-85, rgba(0, 0, 0, 0.85));

      /* H5/medium */
      font-family: Roboto;
      font-size: 16px;
      font-style: normal;
      font-weight: 500;
      line-height: 24px;
      /* 150% */
    }

    .modal-content {
      display: flex;
      padding: 24px;
      flex-direction: column;
      align-items: flex-start;
      gap: 10px;
      align-self: stretch;
    }

    .tile-url {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      gap: 8px;
      align-self: stretch;
    }

    .copy-btn {
      display: flex;
      padding: var(--radius-small, 4px) 8px;
      justify-content: center;
      align-items: center;
      gap: 8px;

      border-radius: var(--spacing-micro, 2px);
      background: #00BEBE;
    }

    .download-modal {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      gap: 8px;
      align-self: stretch;
    }

    .btn {
      display: flex;
      height: 38px;
      padding: 8px var(--icon-normal, 16px);
      justify-content: center;
      align-items: center;
      gap: 8px;
      cursor: pointer;

      border-radius: var(--radius-small, 4px);
      border: 1px solid #00BEBE;
      background: #00BEBE;

      /* drop-shadow / button-primary */
      box-shadow: 0px 2px 0px 0px rgba(0, 0, 0, 0.04);

      color: var(--character-primary-inverse, #FFF);
      text-align: center;
      /* Body/regular */
      font-family: Roboto;
      font-size: 14px;
      font-style: normal;
      font-weight: 400;
      line-height: 22px;
      /* 157.143% */
    }

    .url-css {
      width: 100%;
      display: flex;
      flex-direction: row;
    }

    .url-input {
      display: flex;
      padding: 5px 12px;
      align-items: center;
      flex: 1 0 0;
      width: 460px;

      border-radius: var(--spacing-micro, 2px);
      border: 1px solid var(--neutral-5, #D9D9D9);
      background: var(--neutral-1, #FFF);
    }

    .download-text {
      margin-top: 2px;
    }

    #close {
      border: none;
      background-color: #ffffff;
      cursor: pointer;
    }
  </style>
  <div id="wrapper">
    <div class="modal-header">
      <div class="modal-title">ダウンロード</div>
      <button id="close">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path
            d="M8.92473 7.99916L13.6122 2.41166C13.6908 2.31881 13.6247 2.17773 13.5033 2.17773H12.0783C11.9944 2.17773 11.914 2.21523 11.8587 2.27952L7.99258 6.88845L4.12651 2.27952C4.07294 2.21523 3.99258 2.17773 3.90687 2.17773H2.48187C2.36044 2.17773 2.29437 2.31881 2.37294 2.41166L7.06044 7.99916L2.37294 13.5867C2.35534 13.6074 2.34405 13.6327 2.3404 13.6596C2.33676 13.6865 2.34092 13.7139 2.35239 13.7386C2.36386 13.7632 2.38216 13.784 2.40511 13.7985C2.42806 13.8131 2.4547 13.8207 2.48187 13.8206H3.90687C3.9908 13.8206 4.07115 13.7831 4.12651 13.7188L7.99258 9.10988L11.8587 13.7188C11.9122 13.7831 11.9926 13.8206 12.0783 13.8206H13.5033C13.6247 13.8206 13.6908 13.6795 13.6122 13.5867L8.92473 7.99916Z"
            fill="black" fill-opacity="0.45" />
        </svg>
      </button>

    </div>

    <div class="modal-content">
      <!-- --download m1-- -->
      <div class="download-modal">
        <div class="download-title">
          集計データ(CSV形式)
        </div>
        <button class="btn" id="download-csv-file">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M4.70312 6.01611L7 8.31239L9.29688 6.01611" stroke="white" stroke-width="1.5"
              stroke-linecap="round" stroke-linejoin="round" />
            <path d="M7 2.1875V8.31089" stroke="white" stroke-width="1.5" stroke-linecap="round"
              stroke-linejoin="round" />
            <path
              d="M11.8125 8.3125V11.375C11.8125 11.491 11.7664 11.6023 11.6844 11.6844C11.6023 11.7664 11.491 11.8125 11.375 11.8125H2.625C2.50897 11.8125 2.39769 11.7664 2.31564 11.6844C2.23359 11.6023 2.1875 11.491 2.1875 11.375V8.3125"
              stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
          <span class="download-text">ダウンロード</span>
        </button>
      </div>

      <!-- --download m2: style-- -->
      <div class="download-modal">
        <div class="download-title">
          3D Tiles スタイル(JSON形式)
        </div>
        <button class="btn" id="download-style-btn">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M4.70312 6.01611L7 8.31239L9.29688 6.01611" stroke="white" stroke-width="1.5"
              stroke-linecap="round" stroke-linejoin="round" />
            <path d="M7 2.1875V8.31089" stroke="white" stroke-width="1.5" stroke-linecap="round"
              stroke-linejoin="round" />
            <path
              d="M11.8125 8.3125V11.375C11.8125 11.491 11.7664 11.6023 11.6844 11.6844C11.6023 11.7664 11.491 11.8125 11.375 11.8125H2.625C2.50897 11.8125 2.39769 11.7664 2.31564 11.6844C2.23359 11.6023 2.1875 11.491 2.1875 11.375V8.3125"
              stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
          <span class="download-text">ダウンロード</span>
        </button>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
  <script>
    const downloadCsvBtn = document.getElementById("download-csv-file");
    const downloadJsonStyleBtn = document.getElementById("download-style-btn");

    document.getElementById("close").addEventListener("click", (e) => {
      parent.postMessage({ type: "closeModal" }, "*");
    });

    //send 3d tiles url to server

    let jsonStyleData;
    let csvReceivedData;
    addEventListener("message", (e) => {
      if (e.source !== parent) return;
      if (e.data.style) {
        jsonStyleData = e.data.style;
      }

      if (e.data.csv) {
        csvReceivedData = e.data.csv;
      }

      // parent.postMessage({ type: "showModal", styleData: jsonDataStyle, csvSendData: csvContent }, "*");

    });

    downloadCsvBtn.addEventListener("click", () => {
      if (csvReceivedData.length <= 0) return;
      const csvContent = d3.csvFormat(csvReceivedData, Object.keys(csvReceivedData[0]));
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.setAttribute('href', url);
      a.setAttribute('download', 'download.csv');
      a.click();
      a.remove();
    })

    //download plugin input data as json file
    function downloadObjectAsJson(exportObj, exportName) {
      var dataStr =
        "data:text/json;charset=utf-8," +
        encodeURIComponent(JSON.stringify(exportObj));
      var downloadAnchorNode = document.createElement("a");
      downloadAnchorNode.setAttribute("href", dataStr);
      downloadAnchorNode.setAttribute("download", exportName + ".json");
      document.body.appendChild(downloadAnchorNode); // required for firefox
      downloadAnchorNode.click();
      downloadAnchorNode.remove();
      // showNotification("ダウンロードが成功しました!", "#00B68D");
    }

    downloadJsonStyleBtn.addEventListener("click", (e) => {
      e.preventDefault();
      const FILE_NAME = "download";
      if (!jsonStyleData) return;
      downloadObjectAsJson(jsonStyleData, FILE_NAME);
    });
  </script>
  `;

  let messageFromPlugin;
  let initiallyDataFromPlugin;

  reearth.on("message", (msg) => {
  if (msg.type === "resize") {
  reearth.ui.resize?.(
  msg.expanded ? 180 : 350,
  msg.expanded ? 46 : msg.heightWp,
  msg.expanded ? undefined : false
  );
  }

  //show modal
  if (msg.type === "showModal") {
  reearth.modal.show(modal);
  reearth.modal.postMessage(
  { style: msg.styleData, csv: msg.csvSendData },
  "*"
  );
  }

  //close modal
  if (msg.type === "closeModal") {
  reearth.modal.close();
  }

  // Popup
  if (msg.type === "showPopup") {
  reearth.popup.show(popup, {
  position: "right-start",
  offset: {
  mainAxis: 4,
  crossAxis: 124,
  },
  });
  reearth.popup.postMessage({ guideImage: msg.guideImage }, "*");
  }

  if (msg.type === "closePopup") {
  reearth.popup.close();
  reearth.ui.postMessage({ closePopup: true, handle: "closePopup" }, "*");
  }

  if (msg.type === "sendMessage") {
  messageFromPlugin = msg.message;
  }

  if (msg.type === "sendDataInitially") {
  initiallyDataFromPlugin = msg.message;
  }

  if (msg.type === "sendDataToLayerManagementPlugin") {
  let targetId = reearth.plugins.instances.filter(
  (obj) => obj.extensionId == "layer-management"
  )[0]?.id;
  if (targetId) {
  reearth.plugins.postMessage(targetId, msg.message);
  }
  }
  });

  const handles = {};

  handles.initWidget = () => {
  reearth.ui.postMessage({
  handle: "initWidget",
  title: "initWidget",
  property: reearth.widget.property,
  });
  };

  reearth.on("update", () => {
  reearth.ui.postMessage({
  handle: "handleWidget",
  property: reearth.widget.property,
  });
  });

  reearth.on("resize", (mousedata) => {
  reearth.ui.postMessage(
  {
  type: "mousedata",
  payload: mousedata,
  },
  "*"
  );
  });

  reearth.on("message", (msg) => {
  if (msg && msg.action) {
  handles[msg.action]?.(msg.payload);
  }
  });

  reearth.on("pluginmessage", (msg) => {
  const defaultMessage = {
  message: "settings",
  url: initiallyDataFromPlugin.csvUrl,
  satellite: "",
  datetime: "",
  title: initiallyDataFromPlugin.csvTitleToSend,
  colors: {
  床上: {
  木造: "#0000FF",
  レンガ造: "#FA0000",
  不明: "#FFFF00",
  },
  床下: {
  木造: "#00FFFF",
  レンガ造: "#FFB8E5",
  不明: "#8B4513",
  },
  浸水: {
  非木造: "#9370DB",
  },
  },
  };


  const sendMessage = messageFromPlugin ? messageFromPlugin : defaultMessage;

  reearth.plugins.postMessage(msg.sender, sendMessage);
  });